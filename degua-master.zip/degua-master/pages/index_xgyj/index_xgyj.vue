<template>
	<view>
		<view v-html="res">
			
		</view>
	</view>
</template>

<script>
	import details from "@/data/article.js"
	export default {
		data() {
			return {
				res: ''
			};
		},
		onLoad(options) {
			console.log(options.id);
			let id = options.id;
			let result = details.xgyj.find(r => (r.id == id));
			console.log(result);
			// console.log(details[0].xgyj);
			this.res = result.details;
		}
	}
</script>

<style lang="scss">
	page {
		text-align: center;
	}
</style>
