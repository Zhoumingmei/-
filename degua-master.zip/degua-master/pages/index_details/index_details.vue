<template>
	<view>
		<view v-html="res">
			
		</view>
		
	</view>
</template>

<script>
	import data from '@/data/article.js'
	export default {
		data() {
			return {
				res: ''
			};
		},
		onLoad(options) {
			// console.log(options.title);
			let a = data.pzzs.find(r => (r.name == options.title))
			// console.log(a);
			this.res = a.html;
		}
	}
</script>

<style lang="scss">

</style>
