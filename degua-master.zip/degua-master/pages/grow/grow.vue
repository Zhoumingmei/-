<template>
	<view class="container">
		<view class="content">
			<view class="choose" @click="changClass(1)" :class="{black:c == 1}">
				<image
					src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/%E5%9B%BE%E6%A0%87/%E5%87%BA%E8%8B%97%E6%9C%9F.svg?sign=63e3806fddead28dbea5e69361308e6a&t=1651932314"
					mode=""></image>
				<text>种植匹配</text>
			</view>
			<view class="choose" @click="changClass(2)" :class="{black:c == 2}">
				<image
					src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/%E5%9B%BE%E6%A0%87/%E7%97%85%E8%99%AB%E5%AE%B3.svg?sign=3afc9af62e0b16c0a8b1236312b46209&t=1651932576"
					mode=""></image>
				<text>病害虫识别</text>

			</view>
		</view>
		<view class="content2">
			<!--  -->
			<view class="cos" style="display: flex; align-items: center;" v-if="c ==  1">
				<view style="display: flex; align-items: center;" class="choose" @click="classChang(1)"
					:class="{classchang:cls == 1}">

					<image
						src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/%E5%9B%BE%E6%A0%87/%E5%8C%B9%E9%85%8D.svg?sign=05c6e2992019e88620794bd7e1a09d8d&t=1651932660"
						mode=""></image>
					<text>根据地区匹配</text>
				</view>

				<view style="display: flex; align-items: center;" class="choose" @click="classChang(2)"
					:class="{classchang:cls == 2}">

					<image
						src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/%E5%9B%BE%E6%A0%87/%E5%8C%B9%E9%85%8D.svg?sign=05c6e2992019e88620794bd7e1a09d8d&t=1651932660"
						mode=""></image>
					<text>根据品种匹配</text>
				</view>
			</view>
			<!--  -->
			<view v-if="c ==  2">
				<text class="choose" @click="classChang(1)" :class="{classchang:cls == 1}">
					拍照识别
				</text>
				<text class="choose" @click="classChang(2)" :class="{classchang:cls == 2}">
					精细识别
				</text>
			</view>
			<!-- 第一种 -->
			<view v-if="c==1 && cls == 1">
				<view class="choose-address">
					请选择所在地区
				</view>
				<pickerAddress @change="change">
					<view class="address">
						<view>{{addresslist[0]}}</view>
						<view>{{addresslist[1]}}</view>
						<view>{{addresslist[2]}}</view>
					</view>
				</pickerAddress>
			</view>
			<!-- 第二种 -->
			<view class="breed" v-if="c == 1 && cls == 2">
				<text class="choose-breed">请输入品种信息</text>
				<view class="breed-list">
					<view class="views" @click="open">
						{{choose}}
					</view>
					<uni-popup ref="popup" type="top" background-color="#fff">
						<view style="height: 500px;">
							<text>Popup</text>
							<button @click="close">关闭</button>
							<uni-indexed-list :options="list" :showSelect="false" @click="bindClick"></uni-indexed-list>
						</view>

					</uni-popup>
				</view>

			</view>
			<!--  -->
			<view class="upload" v-if="c == 2 && cls == 2">
				<view class="table">
					<uni-table stripe emptyText="暂无更多数据">
						<uni-tr>
							<uni-th align="center">所在地</uni-th>
							<uni-th align="center">海南省三亚市崖州区</uni-th>
						</uni-tr>
						<uni-tr>
							<uni-td>种植品种</uni-td>
							<uni-td><input type="text"></uni-td>
						</uni-tr>
						<uni-tr>
							<uni-td>发病时间</uni-td>
							<uni-td><input type="text"></uni-td>
						</uni-tr>
						<uni-tr>
							<uni-td>施肥时间</uni-td>
							<uni-td><input type="text"></uni-td>
						</uni-tr>
						<uni-tr>
							<uni-td>施肥种类</uni-td>
							<uni-td><input type="text"></uni-td>
						</uni-tr>
						<uni-tr>
							<uni-td>施肥量</uni-td>
							<uni-td><input type="text"></uni-td>
						</uni-tr>
						<uni-tr>
							<uni-td>土壤含水量</uni-td>
							<uni-td><input type="text"></uni-td>
						</uni-tr>
						<uni-tr>
							<uni-td>种植密度</uni-td>
							<uni-td><input type="text"></uni-td>
						</uni-tr>
					</uni-table>
					<!-- 上传 -->
					<view class="upload" v-if="c == 2 && cls == 2">
						<uni-file-picker @select="select" ref="files" style="color: #000;"
							limit="1" :del-icon="true" :disable-preview="false" :imageStyles="imageStyles"
							file-mediatype="image">点我上传图片</uni-file-picker>
					</view>
					<view class="btn" v-if="c == 2" @click="upload(2)">
						<text>
							匹配
						</text>
					</view>
				</view>


			</view>
			<!--  -->
			<view class="upload" v-if="c == 2 && cls == 1">


				<!-- <text class="up-click"> -->
				<uni-file-picker @select="select" ref="files" style="color: #000;" limit="1"
					:del-icon="true" :disable-preview="false" :imageStyles="imageStyles" file-mediatype="image">点我上传图片
				</uni-file-picker>
				<!-- 点击上传图片 -->
				<!-- </text> -->
			</view>
			<view class="btn" v-if="c == 2 && cls == 1" @click="upload(1)">
				<text>
					匹配
				</text>
			</view>
		</view>

		<view class="result">
			<view class="result-t">
				<text @click="pipei">匹配结果</text>
			</view>
			<!-- 第一种 -->
			<view v-if="c==1 && cls == 1">
				<view class="table">
					<uni-table emptyText="暂无更多数据">
						<uni-tr>

							<th class="row-0" style="width:150px;height:50px;">
								<div class="biaotou">
									<div class="biaotoutxt1">适种时间</div>
									<div class="biaotoutxt2">适种品种</div>
								</div>
								<table>
									<td class="first"></td>
								</table>
							</th>
							<!-- 表头 -->
							<uni-th align="center" v-for="(month,index) in 12" :key="index">{{index +1}}月</uni-th>


						</uni-tr>


						<!-- 适中品种 -->

						<uni-tr v-for="(p,ind) in pipeipz" :key="ind">
							<uni-td align="center">{{p}}</uni-td>
							<uni-td align="center" v-for="(m,i) in pipeisj" :key="i">{{ m ? '✔' : '-'}}</uni-td>
						</uni-tr>



					</uni-table>
				</view>
			</view>
			<!-- 第二种 -->
			<view v-if="c == 1 && cls == 2">
				<view class="table">
					<uni-table stripe emptyText="暂无更多数据">
						<uni-tr>
							<uni-th>地区</uni-th>
							<uni-th>生育期</uni-th>

						</uni-tr>
						<uni-tr v-for="(i,index) in breedAddress" :key="index">
							<uni-td>{{i}}</uni-td>
							<uni-td>{{breedGrow}}天</uni-td>
						</uni-tr>

					</uni-table>
				</view>
			</view>
			<!-- 拍照识别 -->
			<view v-if="c == 2 && cls == 1">
				<view class="res" v-if="showRes != 1">
					暂无数据
				</view>
				<view class="res" v-if="showRes == 1">
					病因：西瓜霜霉病，古巴假霜霉侵染引起。主要为害西瓜叶片，全生育期均可发病。苗期染病，子叶上产生黄化褪绿，后扩展成枯黄色的病斑，子叶枯死。适温高湿有利于西瓜霜霉病的发生，温度在16-20℃，遇多雨或雾大露重时容易发病。生产上浇水过量、地势低洼、种植过密、排水不畅、通风透光差的瓜田发病重。
					防治方法：农业防治和化学防治为主。首先培育壮苗，定植时严格淘汰病苗；选择地势较高，排水良好的地块种植；施用腐熟有机肥，增施磷钾肥，避免偏施氮肥，防止植株徒长。在温室、大棚或地膜覆盖栽培中要严格控制温、湿度，注意通风透光，加强田间栽培管理。最后结合化学药剂进行防治。
					为了改善和增强植株生理代谢机能，增强西瓜本身对病害的主动抵御机制，采用乙磷铝和磷酸二氢钾合理混合，叶面喷洒的方法，取得明显的防病效果和增产效果。或用72%克露可湿性粉剂700倍液，或72.2%普力克水剂800-1000倍液，或69%安克锰锌可湿性粉剂800-1000倍液，或1:（0.6-0.8）:（240-320）波尔多液等，均可收到较好的防治效果。
				</view>

			</view>
			<!-- 精细识别 -->
			<view v-if="c == 2 && cls == 2">
				<view class="res" v-if="showRes != 2">
					暂无数据
				</view>
				<view class="res" v-else-if="showRes == 2">
					炭疽病防治：
					1、实行轮作
					甜瓜应与粮食等非葫芦科作物实行5-7 a的轮作。选择排水良好的沙壤土种植避免在低洼、排水不良的地块。
					2、培育壮苗
					选无病健康的种子。浸种前，用50°C温水或药物对种子进行消毒。采用大中棚客土育苗，用无病新土配制营养土，床土消毒，控制好床土的湿度和棚内温度，对苗床精心管理以培育壮苗。
					3、栽培管理
					栽培甜瓜的地块要多施腐熟的有机肥，注意氮、磷、钾配合施用，以满足植株生长需要，提高抗病能力。雨季注意排;坐果后果实下面最好铺草垫瓜，防止果实直接与土壤接触。伸蔓期浇水宜小水暗浇，不要大水漫灌，地面保持见干见湿。
					4、化学防治
					在甜瓜炭疽病发病初期，用50%甲基托不津可湿性粉剂800倍溶液、70%代森 锰锌可湿性粉剂300~500倍溶液、50%多菌灵可湿性粉剂500倍溶液、75%
					百菌清可湿性粉剂600倍溶液、80%炭疽福美可湿性粉剂800倍溶液、65%代森锌可湿性粉剂400倍溶液、20%农抗120水剂150-200倍溶液 每7
					d左右喷1次，连喷2~3次，最好用几种药交替喷，防止产生抗药性;也可用45%百菌清烟剂熏杀每667 m2每次250 g,7 d熏1次，连熏3次。

					蚜虫防治：
					1、铺设银灰膜避蚜。利用蚜虫对银灰的驱避性,对栽培甜瓜的畦垄铺设银灰膜。
					2、黄板诱蚜。就地取简易板材黄漆刷板涂上机油吊至棚中，30 ~ 50平方米挂一块诱蚜板。
					天敌生物防治:保护地栽培可以放养丽蚜小蜂防治蚜虫。
					3、药剂防治。可选用25%阿克泰水分散粒剂4 000 ~ 6 000倍液，或1 %印楝素水剂800倍液,或48%乐斯本乳油3000倍液，2.5%功夫水剂1 500倍液,
					10%吡虫啉可湿性粉剂1000倍液喷施。


				</view>

			</view>
		</view>
	</view>
</template>

<script>
	import pickerAddress from '@/components/pickerAddress/pickerAddress.vue'
	import dataTree from '@/data/data-choose.js'
	import data from '@/data/data-result.js'
	import list from '@/data/list.json'
	export default {
		components: {
			pickerAddress
		},
		data() {
			return {
				imageStyles: {
					width: 280,
					height:150,
					border: {
						color: "#fff",
						width: 0,
						style: '',
						radius: '15px'
					}
				},
				pz: '',
				// classes: '1-0',
				dataTrees: '',
				c: 1,
				cls: 1,
				addresslist: ['xx省', 'xx市', 'xx区'],
				resI: '',
				pipeipz: '',
				pipeisj: '',
				list: '',
				datas: '',
				breedAddress: '',
				breedGrow: '',
				breed: '',
				paths: '',
				showRes: '',
				choose: '点我选择品种'
			};
		},

		onLoad() {
			console.log(dataTree, 'data');
			this.dataTrees = dataTree;
			this.list = list
			this.datas = data
		},

		methods: {
			// 获取上传状态
			select(e) {
				console.log('选择文件：', e.tempFilePaths)
				this.paths = e.tempFilePaths;
				console.log(this.paths);
			},
			upload(id) {
				console.log("132123",id);
				if (this.paths) {
					if (id == 1) {
						this.showRes = "1"
					} else if (id == 2) {
						this.showRes = "2"
					}
				}

			},
			bindClick(e) {
				console.log('点击item，返回数据' + JSON.stringify(e))
				console.log(e.item.name);
				let n = e.item.name;
				// console.log(n, "name");
				let data = this.datas[0].breed;
				// console.log(data, "data");
				let res = data.find(d => (d.name == n))
				// console.log(res);
				this.breed = res;
				this.breedAddress = res.address;
				this.breedGrow = res.grow;
				this.$refs.popup.close()
				// console.log("1231231");
				this.choose = n
			},
			close() {
				this.$refs.popup.close()
			},
			open() {
				this.$refs.popup.open('top')
				
			},
			pipei() {},
			onnodeclick(e) {
				console.log(e);
			},
			onpopupopened(e) {
				console.log('popupopened');
			},
			onpopupclosed(e) {
				console.log('popupclosed');
			},
			onchange(e) {
				console.log('onchange:', e);
			},
			changClass(i) {
				console.log(i);
				this.c = i
			},
			classChang(cls) {
				this.cls = cls
			},
			change(data) {
				console.log(data.index, 'index');
				this.resI = data.index;
				this.$set(this.addresslist, 0, data.data[0]);
				this.$set(this.addresslist, 1, data.data[1]);
				this.$set(this.addresslist, 2, data.data[2]);
				let a = this.resI.slice(0, 3).toString();
				let ccc = this.datas[0].address
				let res = ccc.find(p => (p.index == a))
				this.pipeipz = res.fit
				this.pipeisj = res.time;
			},
		}
	}
</script>

<style lang="scss">
	.container {

		.content {
			color: #fff;
			font-size: 35rpx;
			display: flex;
			justify-content: space-around;
			align-items: center;

			.choose {
				border: 1px solid #999;
				border-radius: 15px;
				padding: 5px 40rpx;
				margin: 10px 0;
				background-color: #9EAA9E;

				display: flex;
				align-items: center;

				image {
					width: 40px;
					height: 40px;

				}

			}

			.black {
				background-color: #EB4B4B;
			}
		}

		.content2 {
			color: #fff;

			.breed {
				.choose-breed {
					display: block;
					font-size: 45rpx;
					padding: 10px;
					color: #000;
				}

				.breed-list {

					text-align: center;
					color: #000;
					display: flex;
					flex-wrap: wrap;
					justify-content: center;
					box-sizing: border-box;

					.views {
						padding: 15rpx 10rpx;
						background-color: #C0D9BC;
						border-radius: 10px;
						// width: 98px;
						margin: 10px;


					}


				}
			}

			text-align: center;
			margin: 0 10px;
			padding: 10px 0;

			.choose {
				display: flex;
				align-items: center;
				margin: 5px;
				display: inline-block;
				font-size: 35rpx;
				border: 1px solid #9EAA9E;
				border-radius: 20rpx;
				padding: 16rpx 40rpx;
				background-color: #9EAA9E;

				image {
					width: 40rpx;
					height: 40rpx;

				}
			}

			.classchang {
				background-color: #EB4B4B;
			}

			.choose-address {
				color: #000;
				font-size: 45rpx;
				padding: 10px;
			}

			.address {
				display: flex;
				justify-content: space-evenly;
				padding-top: 55rpx;

				view {
					height: 50rpx;
					width: 150rpx;
					padding: 15rpx 25rpx;
					background-color: #C0D9BC;
					margin-bottom: 40rpx;
					color: #fff;
					border-radius: 30rpx;
				}
			}

			.btn {
				padding-top: 10rpx;

				text {
					color: #fff;
					font-size: 40rpx;
					border-radius: 20rpx;
					background-color: #51A63E;
					padding: 10rpx 90rpx;
				}
			}

			.upload {
				display: flex;
				justify-content: center;

				.up-click {
					display: flex;
					align-items: center;
					justify-content: center;
					width: 400rpx;
					height: 220rpx;
					margin: 20rpx;
					border-radius: 60rpx;
					background-color: #DDDDDD;
				}
			}
		}

		.table {
			// width: 80%;
			// margin: 0 auto;
			padding: 10px 0;

			.biaotou {
				line-height: 5px;
				text-align: left;
			}

			.biaotoutxt1 {
				color: #000;
				/* 文字颜色  */
				padding: 1px 0 0 65px;
				/* 文字位置  需要手调  */
			}

			.biaotoutxt2 {
				color: #000;
				padding: 15px 0 0 5px;
			}

			td[class=first]:before {
				content: "";
				position: absolute;
				width: 1px;
				height: 157px;
				/* 需要手调 ，线的长度 */
				top: 0;
				/* 需要手调 ，线的位置*/
				left: 0;
				background-color: #000;
				/* 线的颜色 black */
				display: block;
				transform: rotate(-71.5deg);
				/* 需要手调 ，斜线的角度*/
				transform-origin: top;
			}


			.uni-table-th {
				color: black;
				font-size: 30rpx;
				border: 1px solid #DEDEDE;
			}

			.uni-table-td {
				color: #000;
				font-size: 30rpx;
				line-height: 60rpx;
				border: 1px solid #DEDEDE;
			}

			::v-deep .uni-table-tr:nth-of-type(2n) {
				background-color: #D6E3CE;
			}

			::v-deep .uni-table-tr {
				background-color: #F0F0F0;
			}
		}

		.result {
			.res {
				text-align: start;
				margin: 40rpx;
				padding: 20rpx;
				background-color: #F2F2F2;

			}

			text-align: center;
			// border: 1px solid #EAEAEA;
			// background-color: #EAEAEA;
			border-radius: 20px;
			margin: 15px 10px;

			.result-t {
				// text-align: center;
				font-size: 40rpx;
				padding: 10px;

				text {
					color: #fff;
					font-size: 40rpx;
					border-radius: 20rpx;
					background-color: #51A63E;
					padding: 10rpx 90rpx;
				}
			}



		}
	}
</style>
