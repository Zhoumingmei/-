<template>
	<view class="container">
		<view class="poster">
			<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/haibao.png?sign=8c65bbf64234ffcc26ad2698b433aa48&t=1655191076" mode=""></image>
		</view>
		<!-- <image src="/" mode=""></image> -->
		<!-- 公告 -->
		<view class="board">
			<view class="board-tit">
				<text class="board-boa">[公告]</text>
				请遵守规则！
			</view>
		</view>
		<!-- 文章列表 -->
		<view class="knlge" v-for="i in list" :key="i.id" @click="toForum(i.id)">
			<view class="knlge-top">
				<text class="writer">{{i.writer}}</text>
				<text class="time">{{i.time}}</text>
			</view>
			<view class="knlge-btm">
				<text class="btm-tit">{{i.title}}</text>
			</view>
		</view>
	
	
		
	</view>
</template>

<script>
	import data from "@/data/data.json"
	export default {
		data() {
			return {
				list: ''
			};
		},
		onLoad() {
			this.list = data.forum;
			console.log(this.list);
		},
		methods: {
			toForum(id) {
				uni.navigateTo({
					url: "/pages/forum_details/forum_details?id=" + id
				})
			}
		},
	}
</script>

<style lang="scss">
	
		.container {
			.poster {
					text-align: center;
				image {
					width: 96%;
					height: 1000rpx;
				}
			}
			.board {
				.board-tit {
					color: #f00;
					font-weight: bold;
				}
				.board-boa {
					color: #999;
				}
			}
			// padding: 10px;
			.knlge {
				margin: 5px 0;
				background-color: #eaeaea;
				.knlge-top {
					display: flex;
					justify-content: flex-end;
					font-size: 28rpx;
					color: #999;
					padding: 8rpx;
					border-bottom: 0.5px solid #456e45;
					background-color: #456e45;
					.writer {
						width: 80px;
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
					}
					.time {
						padding-left: 10px;
					}
				}
				.knlge-btm {
					padding: 10px;
					// border-bottom: 3px solid #456e45;
					.btm-tit {
						font-size: 36rpx;
					}
				}
			}
		}
	
</style>
