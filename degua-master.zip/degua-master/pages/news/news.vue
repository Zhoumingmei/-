<template>
	<view>
		<view v-html="res">
			
		</view>
	</view>
</template>

<script>
	import news from "@/data/article.js"
	export default {
		data() {
			return {
				article: '',
				res: ''
			}
		},
		onLoad(options) {
			let id = options.id
			this.article = news.article;
			let c = this.article.find(w => (w.id == id))
			console.log(c.wz);
			this.res = c.wz
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
	
</style>
