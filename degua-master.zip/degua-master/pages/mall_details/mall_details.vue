<template>
	<view class="mall">
		<view class="img">
			<swiper style="height: 286px;" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000">
				<swiper-item>
					<view class="swiper-item">
						<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/zhaoxia.jpg?sign=d580619bf7ae8adb4852cc094aea9f52&t=1651159351" mode="widthFix"></image>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="swiper-item">
						<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/zhongtianhong.jpg?sign=2eb77087855eaa008f4b3410fce5e146&t=1651159537" mode="widthFix"></image>
					</view>
				</swiper-item>
			</swiper>
		</view>
		<view class="det">
			<view class="price">
				<view>
					<text class="price_1">￥</text> <text class="price_2">70</text>
					<text class="price_bf">原价：￥80</text>
				</view>
				<view class="sc">收藏</view>
			</view>
			<view class="title">
				<text class="title_left">春晖 彩色小西瓜 专利产品技术 高品质西瓜</text>
				<text class="title_right">分享</text>
			</view>
			<view class="subtitle">
				<text class="subtitle_left">彩色小西瓜 便携 高品质 甜西瓜 味道好</text>
				<text class="subtitle_right">领券 ></text>
			</view>
		</view>
		<view class="ath">

			<view class="address">
				<view>
					<text class="">
						送至
					</text>
					<text class="address_to">
						xxxxxx门店/xxxxxx地址
					</text>
				</view>

				<view class="">
					＞
				</view>
			</view>
			<view class="line"></view>

			<view class="freight">
				<view>
					<text>运费</text>
					<text>包邮</text>
				</view>

				<view class="">
					＞
				</view>
			</view>
			<view class="line"></view>
			<view class="par">
				<view>
					<text>参数</text>
					<text>产地</text>
				</view>

				<view class="">
					＞
				</view>
			</view>
			<view class="line"></view>
		</view>

		<view class="details">
			<view class="lines"></view>
			<view class="xq">
				详情
			</view>
			<view class="lines"></view>
		</view>


	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		},
		onLoad(option) {
			console.log(option.pid);
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #F5F5F5;
		box-sizing: border-box;
		.mall {
			.img {
				// height: 500px;
				.swiper-item {
					text-align: center;
					padding: 10px;
					image {
						width: 100%;
						border-radius: 15rpx;
						// margin: 10rpx;
					}
				}
			}
			.det {
				background-color: #fff;

				.price,
				.title,
				.subtitle {
					display: flex;
					flex-wrap: nowrap;
					justify-content: space-between;
					align-items: center;
					padding: 20rpx 25rpx;
				}

				.price {
					.price_1 {
						color: #69BC69;
						font-size: 28rpx;
					}

					.price_2 {
						color: #69BC69;
						font-size: 40rpx;
						font-weight: bold;
						padding-right: 25rpx;
					}

					.price_bf {
						text-decoration: line-through;
						font-size: 24rpx;
					}

					.sc {
						font-size: 26rpx;
					}
				}

				.title {

					.title_left {
						font-size: 28rpx;
						font-weight: bold;
					}

					.title_right {
						display: block;
						font-size: 28rpx;
						padding: 5rpx 20rpx;
						border-radius: 30rpx;
						color: #fff;
						background-color: #20A721;
					}
				}

				.subtitle {

					.subtitle_left {
						font-size: 24rpx;
						color: #999;
					}

					.subtitle_right {
						font-size: 24rpx;
						color: #20A721;
					}
				}
			}

			.ath {
				padding: 20rpx 25rpx;
				font-size: 18rpx;
				background-color: #fff;
				margin-top: 10rpx;
				.line {
					margin: 28rpx 0;
					border: 1rpx solid #999;
					width: 100%;
				}

				.address,
				.freight,
				.par {
					display: flex;
					justify-content: space-between;
					font-weight: bold;

					text {
						padding-right: 100rpx;
					}
				}
			}

			.details {
				text-align: center;
				display: flex;
				justify-content: center;
				align-items: center;
				.xq {
					padding: 20rpx;
				}
				.lines {
					border: 1px solid #000;
					width: 80px;
				}
			}
		}
	}
</style>
