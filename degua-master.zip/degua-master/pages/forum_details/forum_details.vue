<template>
	<view>
		<view class="title">
			{{res.title}}
		</view>
		<view class="writer">
			发布用户：{{res.writer}}
		</view>
		<view class="zz">
			(此文转载至公众号{{res.zz}})
		</view>
		<view v-html="res.article">
			
		</view>
	</view>
</template>

<script>
	import data from "@/data/article.js"
	export default {
		data() {
			return {
				res: ''
			}
		},
		methods: {
			
		},
		onLoad(option) {
			console.log(option.id);
			console.log(data.forum,"data");
			let result = data.forum.find(p => (p.id == option.id))
			console.log(result,'result');
			this.res = result;
		}
	}
</script>

<style lang="scss">
	page {
		.title {
			font-size: 30rpx;
			font-weight: bold;
		}
		.writer {
			text-align: right;
			font-size: 16rpx;
			padding-right: 30rpx;
		}
		.zz {
			text-align: right;
			font-size: 12rpx;
			padding-right: 30rpx;
		}
	}
</style>
