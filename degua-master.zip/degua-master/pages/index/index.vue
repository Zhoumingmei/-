<template>
	<view class="content">
		<!-- logo -->
		<view class="logo">
			<view class="logo-top">
				<!-- <image src="/static/img/logo.jpg" mode="scaleToFill"></image> -->
				<div></div>
			</view>
			<view class="chart">
				<image
					src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%AE%A2%E6%9C%8D.svg?sign=833ae6f1379ab9e4be61cd88602b838a&t=1651159943"
					mode="scaleToFill"></image>
			</view>
		</view>

		<!-- 轮播图 -->
		<swiper class="swiper-box" :indicator-dots="true" :autoplay="true" indicator-color="#fff" circular
			:interval="3000" :duration="1000">
			<swiper-item v-for="(sitems,index) in swiperdata" :key="index">
				<view class="swiper-item">
					<image :src="sitems.img" mode="aspectFill"></image>
				</view>
			</swiper-item>
		</swiper>
		<!-- 宫格 -->
		<view class="grid">
			<uni-grid :column="5" :showBorder="false" @change="onTo">
				
					<uni-grid-item :index="1">
						<view class="icon">
							<image
								src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E7%A7%8D%E6%A4%8D%E7%A7%91%E6%99%AE.png?sign=6974ccf6b094973f670238368fea6a0b&t=1651925610"
								mode=""></image>
						</view>
						<text class="text">种植科普</text>
					</uni-grid-item>
				
				<uni-grid-item :index="2">
					<view class="icon">
						<image
							src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%8C%85%E8%A3%85%E8%AE%BE%E8%AE%A1.png?sign=2aef78541e3c276c0ba39bba964f3992&t=1651925702"
							mode=""></image>
					</view>
					<text class="text">品种信息</text>
				</uni-grid-item>
				<uni-grid-item :index="3">
					<view class="icon">
						<image
							src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%89%8D%E6%B2%BF%E7%A7%91%E6%8A%80.png?sign=e868884db589a3ccef94a0312c0706b9&t=1651925729"
							mode=""></image>
					</view>
					<text class="text">前沿科技</text>
				</uni-grid-item>
				<uni-grid-item :index="4">
					<view class="icon">
						<image
							src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%89%8D%E6%99%AF%E5%B1%95%E6%9C%9B.png?sign=2069a06bb04905da41aad6503837c5fb&t=1651925783"
							mode=""></image>
					</view>
					<text class="text">智慧农场</text>
				</uni-grid-item>
				<uni-grid-item :index="5">
					<view class="icon">
						<image
							src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E8%81%94%E7%B3%BB%E6%88%91%E4%BB%AC.png?sign=a4f190baacc58e12bbd99dbad480bfa0&t=1651925768"
							mode=""></image>
					</view>
					<text class="text">专家问诊</text>
				</uni-grid-item>
			</uni-grid>
		</view>
		
		<!-- 品种展示 -->
		<uni-section title="品种展示" type="line" subTitle="更多 >" padding>
			<view class="xg">
				<view class="area" v-for="(items,index) in indexdata" :key="index" @click="Todetails(items.title)">
					<image :src="items.img" mode="aspectFill"></image>
					<view class="title">{{items.title}}</view>
					<view class="subtitle">{{items.subtitile}}</view>
				</view>
			</view>
		</uni-section>
		<!-- 西瓜映像 -->
		<uni-section title="西瓜映像" type="line" subTitle="更多 >" padding>
			<view class="xg">
				<view class="area-xg" v-for="v in videoUrl" :key="v.vid">
					<image :src="v.cover" mode="aspectFill">
						<view class="xg-cover" @click="play(v.vid)">
							<image class="play"
								src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/%E5%9B%BE%E6%A0%87/%E6%92%AD%E6%94%BE%20(1).png?sign=35968b7623e419b32d27c766365870f0&t=1652523517"
								mode=""></image>
						</view>
		
					</image>
		
				</view>
		
		
			</view>
		</uni-section>
		<!-- 西瓜影集 -->
		<uni-section title="西瓜影集" type="line" subTitle="更多 >" padding>
			<view class="xg">
				<view class="area-xgyj" v-for="i in xgyj" :key="i.id" @click="toXgyj(i.id)">
					<image :src="i.cover" mode="widthFix"></image>
					<text>{{i.title}}</text>
				</view>
		
		
			</view>
		</uni-section>
		<!-- 最新资讯 -->
		<uni-section title="最新资讯" type="line" subTitle="更多 >" padding>
			<view class="news">
				<view class="newslist" v-for="(nitems,index) in newsdata" :key="index" @click="toNews(nitems.id)">
					<view class="left">
						<image :src="nitems.img" mode="aspectFill"></image>
					</view>
					<view class="right">
						<view class="news-title">
							{{nitems.title}}
						</view>
						<view class="news-witer">
							作者：xxxx
							<text class="news-time">时间：1970-12-12</text>
						</view>
					</view>
				</view>
			</view>
		</uni-section>
		<!-- logo -->
		<view class="logo-btm">
			<view>
			</view>
		</view>
	</view>
</template>

<script>
	import data from '@/data/data.json'
	export default {
		data() {
			return {
				swiperdata: [],
				indexdata: [],
				newsdata: [],
				videoPlay: false,
				videoUrl: '',
				xgyj: ''
			}
		},
		onLoad() {
			// console.log(data, "data");
			this.indexdata = data.index
			this.newsdata = data.news
			this.swiperdata = data.swiper
			this.videoUrl = data.video
			this.xgyj = data.xgyj
			// console.log(this.videoUrl, "url");
		},
		methods: {
			toXgyj(id) {
				// console.log(id,"xgyjid");
				uni.navigateTo({
					url: "/pages/index_xgyj/index_xgyj?id=" + id
				})
			},
			toNews(id) {
				// console.log(id,'id');
				uni.navigateTo({
					url: "/pages/news/news?id=" + id
				})
			},
			Todetails(title) {
				// console.log(title);
				uni.navigateTo({
					url: "/pages/index_details/index_details?title=" + title
				})
			},
			play(vid) {
				// console.log(vid, 'id');
				uni.navigateTo({
					url: '/pages/text/text?video=' + this.videoUrl[vid].videos
				})
			},
			onTo(e) {
				// console.log('123123',e.detail.index);
				uni.navigateTo({
					url: '/pages/index_kepu/index_kepu?id=' + e.detail.index
				})
			}
		}
	}
</script>

<style lang="scss">
	.content {
		.logo {
			display: flex;
			justify-content: space-between;
			align-items: center;

			.logo-top {
				div {
					width: 50px;
					height: 50px;
					background-image: url(../../static/img/logo.jpg);
					background-position: 45% 30%;
					background-size: 200% 200%;
					background-repeat: no-repeat;
				}

			}

			.chart {
				padding-right: 10rpx;

				image {
					width: 30px;
					height: 30px;

				}
			}
		}

		.swiper-box {
			// padding: 5rpx 20rpx;
			height: 400rpx;
			// width: 750rpx;
			width: 100%;

			image {
				height: 400rpx;
				border-radius: 15rpx;
				// width: 750rpx;
				width: 100%;
				overflow: hidden;
			}


		}

		.grid {
			text-align: center;

			.icon {
				padding: 10rpx;

				image {
					width: 80rpx;
					height: 80rpx;
				}
			}
		}
		

		.xg {
			display: flex;
			flex-wrap: wrap;
			.area-xgyj {
				text-align: center;
				text {
					font-size: 14px;
				}
				image {
					display: flex;
					width: 65px;
					padding: 3px;
					border-radius: 30rpx;
				}
			}
			.area-xg {
				padding: 1%;
				text-align: center;
				width: 48%;
				height: 120px;
				image {
					width: 100%;
					height: 100%;
				}
			.xg-cover {
				position: relative;
				.play {
					z-index: 66;
					width: 40px;
					height: 40px;
					position: absolute;
					// background-color: red;
					bottom: 12px;
					right: 6px;
				}
			}
			}

			.area {
				padding: 1%;
				text-align: center;
				width: 48%;
				height: 180px;
				

				image {
					width: 100%;
					height: 70%;
				}

				.title {
					font-size: 40rpx;
					font-weight: bold;
				}

				.subtitle {
					font-size: 30rpx;
					color: #999;
				}
			}
		}

		.news {
			.newslist {
				display: flex;
				border-bottom: 1px solid #888;
				padding: 10rpx;

				.left {
					width: 35%;
					height: 180rpx;

					image {
						width: 100%;
						height: 100%;
					}
				}

				.right {
					display: flex;
					flex-wrap: wrap;
					width: 65%;
					height: 180rpx;

					.news-title {
						height: 60px;
						font-size: 35rpx;
						padding-left: 20rpx;
						font-weight: bold;
					}

					.news-witer {
						align-items: flex-end;
						color: #999;
						font-size: 25rpx;
						padding-left: 20rpx;

						.news-time {
							padding-left: 60rpx;
						}
					}
				}
			}
		}

		.logo-btm {
			view {
				margin: 0 auto;
				width: 150rpx;
				height: 150rpx;
				background-image: url(../../static/img/logo.jpg);
				background-position: 45% 30%;
				background-size: 200% 200%;
				background-repeat: no-repeat;
			}
		}
	}
</style>
