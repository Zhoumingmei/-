<template>
	<view>
		<!-- 顶部筛选 -->
		<view class="scrren">
			<view class="serren-rec">
				<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/3.1-%E4%B8%8A%E6%96%B0.svg?sign=8ca58291a9428c237abc0890bab974f3&t=1651159791" mode="widthFix"></image>
				<view class="title">
					今日上新
				</view>
			</view>
			<view class="serren-rec">
				<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E3%80%90%E9%98%BF%E6%9E%9C%E7%93%9C%E7%93%9C%E3%80%91%E5%9B%BE%E6%A0%87-%E8%A5%BF%E7%93%9C-01.svg?sign=a6e8312252916f789c04429b01883ac7&t=1651159740" mode="widthFix"></image>
				<view class="title">
					好瓜专区
				</view>
			</view>
			<view class="serren-rec">
				<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%86%9C%E8%B5%84%20(1).svg?sign=e5485a3ac0ba9717a295a0bf7d4991e8&t=1651159759" mode="widthFix"></image>
				<view class="title">
					种植农资
				</view>
			</view>
			<view class="serren-rec">
				<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%88%86%E7%B1%BB.svg?sign=75c31f4a330699a240f7d27a5407fc94&t=1651159772" mode="widthFix"></image>
				<view class="title">
					分类选择
				</view>
			</view>
		</view>
		<view class="choose">
			<text class="choose-list">综合</text>
			<text class="choose-list">销量</text>
			<text class="choose-list">价格</text>
			<text class="choose-list">筛选</text>
		</view>
		<!-- 商品list -->
		<view class="product-list" v-for="items in products" :key="items.pid" @click="toBuy(items.pid)">
			<view class="product-img">
				<image :src="items.img" mode="aspectFill"></image>
			</view>
			<view class="product-title">
				<text>{{items.title}}</text>
				<view class="price">
					<text>￥</text>
					{{items.price}}
					<image src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%95%86%E5%9F%8E.png?sign=f7291ca79070aad76c4b7396376056a5&t=1651211360" mode=""></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import data from '@/data/data.json'
	export default {
		data() {
			return {
				products: []
			};
		},
		onLoad() {
			this.products = data.products
		},
		methods: {
			toBuy(pid) {
				console.log("去详情页",pid);
				uni.navigateTo({
					url: "/pages/mall_details/mall_details?pid=" + pid
				})
			}
		},
	}
</script>

<style lang="scss">
	.scrren {
		display: flex;
		text-align: center;
		border: 1px solid #999;
		border-radius: 15px;
		margin: 10px;
		padding: 10px;
		background-color: #F0F0F0;

		.serren-rec {
			width: 25%;

			image {
				width: 100rpx;
			}
		}
	}

	.choose {
		display: flex;
		justify-content: space-evenly;

		.choose-list {
			border: 1px solid #999;
			border-radius: 15px;
			padding: 5px 20px;
			background-color: #F0F0F0;
		}
	}

	.product-list {
		display: flex;

		.product-img {
			width: 200rpx;
			padding: 10px;
			height: 88px;
			image {
				width: 200rpx;
				height: 88px;
				border-radius: 15px;
			}
		}

		.product-title {
			// width: 50%;
			padding-top: 20rpx;
			text {
				// font-weight: bold;
				// color: red;
			}
			.price {
				padding-top: 40rpx;
				color: #EB2C1A;
				font-size: 40rpx;
				font-weight: bold;
				text {
					font-size: 30rpx;
				}
				image {
					width: 48rpx;
					height: 48rpx;
					padding-left: 240rpx;
				}
			}


		}
	}
</style>
