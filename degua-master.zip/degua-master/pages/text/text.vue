<template>
	<view>
		<view v-if="videoPlay" class="video">
			<video controls id="myvideo" :src="videoUrl" @fullscreenchange="screenChange" :autoplay="true"
				direction="0"></video>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				videoPlay: false,
				videoUrl: ''
			};
		},
		methods: {
			screenChange(e) {
				let fullScreen = e.detail.fullScreen; // 值true为进入全屏，false为退出全屏
				console.log(e, "全屏");
				if (!fullScreen) {
					//退出全屏
					this.videoPlay = false; // 隐藏播放盒子
					uni.navigateBack({})
				}
			},
		},
		onLoad(options) {
			console.log(options.video);
			this.videoUrl = options.video;
			this.videoPlay = true
			this.videoContext = uni.createVideoContext('myvideo', this);
			this.videoContext.requestFullScreen();
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #000;
	}
	.video {
		width: 100%;
		video {
			width: 100%;
		}
	}
</style>
