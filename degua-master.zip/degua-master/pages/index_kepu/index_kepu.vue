<template>
	<view>
		<view v-html="res"></view>
	</view>
</template>

<script>
	import data from "@/data/article.js"
	export default {
		data() {
			return {
				res: ''
			}
		},
		methods: {

		},
		onLoad(option) {
			// console.log(option.id,data,"data");
			let a = data.gg.find(r => (r.id == option.id))
			// console.log(a,"aaaa");
			if(a) {
				this.res = a.html
			} else {
				this.res = `<div style="padding:10px;">
  <h1 style="text-align: center;">
    <font face="黑体"><strong>暂无数据</strong></font>
  </h1>
</div>`
			}
		}
	}
</script>

<style lang="scss">
	p {
		padding: 10px;
	}
	h2 {
		padding: 10px;
	}
</style>
