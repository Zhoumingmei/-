<template>
	<view>
		<!-- 头像区 -->
		<view class="avatar">
			<image src="../../static/icon/user.png" mode=""></image>
			<view class="">
				点击登录
			</view>
		</view>
		<!-- 订单 -->
		<uni-grid style="margin-top: 10rpx;" :show-border="false" :column="4">
			<view class="grid">
				<uni-grid-item>
					<image src="/static/icon/daifukuan.svg" mode=""></image>
					<text>待付款</text>
				</uni-grid-item>
			</view>
			<view class="grid">
				<uni-grid-item>
					<image src="/static/icon/daishouhuo.svg" mode=""></image>
					<text>待收货</text>
				</uni-grid-item>
			</view>
			<view class="grid">
				<uni-grid-item>
					<image src="/static/icon/pingjia.svg" mode=""></image>
					<text>待评价</text>
				</uni-grid-item>
			</view>
			<view class="grid">
				<uni-grid-item>
					<image src="/static/icon/shouhou.svg" mode=""></image>
					<text>售后</text>
				</uni-grid-item>
			</view>
		</uni-grid>
		<!-- qit -->
		<!-- 123123 -->
		<view class="cell">
			<uni-list>
				<uni-list-item title="我的农场" showArrow link
					thumb="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E7%A7%8D%E6%A4%8D%E7%AE%A1%E7%90%86.svg?sign=b89aa0a0b3ee06ca7b0cafc4ace7ca9f&t=1651224766"
					thumb-size="medium"></uni-list-item>
				<uni-list-item title="我的帖子" showArrow link
					thumb="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%B8%96%E5%AD%90%E7%AE%A1%E7%90%86.svg?sign=960cfe99d5d796cf71ed8e5ef244c609&t=1651224796"
					thumbSize="medium"></uni-list-item>
				<uni-list-item title="我的收藏" showArrow link
					thumb="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%B8%96%E5%AD%90%E6%94%B6%E8%97%8F.svg?sign=cb30e1ddfab25d82da0ae727055d9bf6&t=1651224860"
					thumbSize="medium"></uni-list-item>
				<uni-list-item title="联系我们" showArrow link
					thumb="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E5%AE%A2%E6%9C%8D.svg?sign=688e4ae771c39e9ed17ff7ad073996e9&t=1651224895"
					thumbSize="medium"></uni-list-item>
				<uni-list-item title="西瓜溯源" showArrow link
					thumb="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80.svg?sign=b329f9ec128a5d8d5c78c25416351371&t=1651224926"
					thumbSize="base"></uni-list-item>

				<uni-list-item title="设置" showArrow link	
					thumb="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/icon/%E8%AE%BE%E7%BD%AE.svg?sign=e779f7c67d5de9467df5cb19446ef2e2&t=1651224960"
					thumbSize="base"></uni-list-item>
			</uni-list>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="scss">
	page {
		.avatar {
			text-align: center;
			background-color: #456e45;
			padding: 50px;
			color: #fff;
			margin-bottom:10rpx ;
			image {
				background-color: aliceblue;
				width: 180rpx;
				height: 180rpx;
				border-radius: 50%;
			}
		}

		.grid {
			text-align: center;
			margin: 0 auto;
			height: 46px;
			overflow: hidden;

			image {
				display: block;
				margin: 0 auto;
				width: 50rpx;
				height: 50rpx;
			}

		}

		.cell {
			margin-top: 5px;
		}

	}
</style>
