export default [{
	dataTreePZ: [{
		text: "朝霞",
		value: "1-0"
	}, {
		text: "众天红",
		value: "2-0"
	}, {
		text: "满月",
		value: "3-0"
	}, {
		text: "美颜",
		value: "4-0"
	}, {
		text: "春晖",
		value: "5-0"
	}, {
		text: "众天1293",
		value: "6-0"
	}, {
		text: "众天6211",
		value: "7-0"
	}, {
		text: "玉琢",
		value: "8-0"
	}, {
		text: "众天2013",
		value: "9-0"
	}],
	dataTreeDW: [{
		text: "10℃",
		value: "2-1"
	}, {
		text: "11℃",
		value: "2-2"
	},{
		text: "12℃",
		value: "2-3"
	},{
		text: "13℃",
		value: "2-4"
	},{
		text: "14℃",
		value: "2-5"
	},{
		text: "15℃",
		value: "2-6"
	},{
		text: "16℃",
		value: "2-7"
	},{
		text: "17℃",
		value: "2-8"
	},{
		text: "18℃",
		value: "2-9"
	},{
		text: "19℃",
		value: "2-10"
	},{
		text: "20℃",
		value: "2-11"
	},{
		text: "21℃",
		value: "2-12"
	},{
		text: "22℃",
		value: "2-13"
	},{
		text: "23℃",
		value: "2-14"
	},{
		text: "24℃",
		value: "2-15"
	},{
		text: "25℃",
		value: "2-16"
	},{
		text: "26℃",
		value: "2-17"
	},{
		text: "27℃",
		value: "2-18"
	},{
		text: "28℃",
		value: "2-19"
	},{
		text: "29℃",
		value: "2-20"
	},{
		text: "30℃",
		value: "2-21"
	},{
		text: "31℃",
		value: "2-22"
	},{
		text: "32℃",
		value: "2-23"
	},{
		text: "33℃",
		value: "2-24"
	},],
	dataTreeGW: [{
		text: "10℃",
		value: "2-1"
	}, {
		text: "11℃",
		value: "2-2"
	},{
		text: "12℃",
		value: "2-3"
	},{
		text: "13℃",
		value: "2-4"
	},{
		text: "14℃",
		value: "2-5"
	},{
		text: "15℃",
		value: "2-6"
	},{
		text: "16℃",
		value: "2-7"
	},{
		text: "17℃",
		value: "2-8"
	},{
		text: "18℃",
		value: "2-9"
	},{
		text: "19℃",
		value: "2-10"
	},{
		text: "20℃",
		value: "2-11"
	},{
		text: "21℃",
		value: "2-12"
	},{
		text: "22℃",
		value: "2-13"
	},{
		text: "23℃",
		value: "2-14"
	},{
		text: "24℃",
		value: "2-15"
	},{
		text: "25℃",
		value: "2-16"
	},{
		text: "26℃",
		value: "2-17"
	},{
		text: "27℃",
		value: "2-18"
	},{
		text: "28℃",
		value: "2-19"
	},{
		text: "29℃",
		value: "2-20"
	},{
		text: "30℃",
		value: "2-21"
	},{
		text: "31℃",
		value: "2-22"
	},{
		text: "32℃",
		value: "2-23"
	},{
		text: "33℃",
		value: "2-24"
	},]
}]
