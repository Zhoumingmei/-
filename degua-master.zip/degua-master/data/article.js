export default {
	article: [{
		"id": "2",
		"wz": `<div style="padding:10px;"><h2 align="center">

  <font face="等线"><strong>我司系列西瓜参选海南省东交会</strong></font>
</h2>
<p align="center"><br /></p>
<font face="等线">&nbsp; &nbsp; &nbsp;1</font>2
<font face="等线">月</font>
<font face="等线">1</font>9
<font face="等线">日，为期</font>
<font face="等线">4天的</font>
<font face="等线">2021年中国(海南)国际热带农产品冬季交易会(以下简称冬交会)落下帷幕。本次冬交会共吸引15.41万余人次进馆逛展;累计现场交易额13.6741亿元。中国农业科学院国家南繁研究院携手崖州湾科技城、中国农业科学院郑州果树研究所，在冬交会上共同向各大客商群众展示南繁科技成果转化带来的“高科技”农产品。</font>
<font face="等线" style="font-size: 14.4px;"><br /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/news1.png?sign=8f7b8c38295dd0fcb3380aad07452b9d&amp;t=1652778069" style="width: 95vw; height: 36vh;" /><br /></font>
<font face="等线" style="font-size: 14.4px;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/news2.png?sign=0dddf926155db54668e1cdb916d46852&amp;t=1652778135" style="width: 95vw; height: 36vh;" /><br />&nbsp; &nbsp; 开幕当天</font>
<font face="等线" style="font-size: 14.4px;">，省委书记沈晓明到</font>
<font face="等线" style="font-size: 14.4px;">冬交会</font>
<font face="等线" style="font-size: 14.4px;">现场巡馆，了解展览和交易情况，强调要深入学习贯彻习近平总书记关于海南工作的系列重要讲话和指示批示精神，坚持特色化、规模化、品牌化、绿色化，推动农业转型升级，夯实乡村振兴经济基础。<br /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/news3.png?sign=d1b4fd09192f5da5fe501c63809e34c7&amp;t=1652778201" style="width: 95vw; height: 36vh;" /></font><br />
<p><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/news4.png?sign=462ec105d8e67fad6ba7d908d44a2879&amp;t=1652778253" style="width: 95vw; height: 36vh;" /><br /></p>
<p>12月16日，省委书记沈晓明来到现代种业与数字农业馆的崖州湾科技城展位了解相关情况。</p>
<p><br /></p>
<p>
  <font face="等线">&nbsp; &nbsp; 沈晓明先后到现代种业与数字农业馆、品牌农产品馆、乡村振兴馆等展馆，详细了解南繁育制种、新品种引进选育、水产种苗产业发展、特色农产品发展、农业信息系统建设等情况。他强调，要加强科技创新和推广应用，转变生产方式和发展方式，推动热带特色高效农业高质量发展。要加大新品种引进选育力度，组织引导农民调优品种结构，扩大特色优质农产品种养规模，促进农业增效、农民增收。要按照全省一张网的要求，推进农业信息系统建设，采集分析共享农业生产、流通、运营等各环节数据，解决农业信息不对称问题。要注重实效、丰富内涵，把冬交会办成热带农产品交易平台和乡村振兴成果展示窗口。</font>
</p>
<p>
  <font face="等线"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/news5.png?sign=e4d6d5c9b4013fba73a5a1e9530ccbf8&amp;t=1652778324" style="width:37vw; height: 22vh;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/news6.png?sign=14afd768730de0dcb8fe512dfb9361a2&amp;t=1652778362" style="width:56vw; height: 22vh;" /></font><br />
</p>
<p>
  <font face="等线" style="font-size: 14.4px;">&nbsp; &nbsp; 中国农科院郑州果树研究所设施西瓜甜瓜团队研发的西瓜，试吃产品一经展出，就被接踵而至的参展群众围得水泄不通。郑州果树研究所科研人员十几年来往返三亚南繁科研育种基地，在海南南繁的天然优势加持下，加速了小果型西瓜优良品种的研发效率，海南得天独厚的自然环境加速了小型西瓜的育种效率，这次展出的</font><span style="font-size: 14.4px;">
  </span>
  <font face="等线" style="font-size: 14.4px;">“美颜”西瓜，就是南繁育种的众多成果之一。随着“南繁硅谷”的建设，将会有越来越多的优质农产品与大家见面。</font><br /></p>
<p>&nbsp;</p>



<h1 style="text-align: center; "><br /></h1></div>`

	}, {
		"id": "1",
		"wz": `<div style="padding:10px;">
  <h2 style="text-align: center;">

    <strong><font face="宋体">虹彩系列西瓜</font><font face="宋体">——金玉玲珑</font></strong></h2>
  <p style="text-align: center;">




    <br /></p>
  <p style="text-align: justify;">
    <font face="宋体">&nbsp; “金玉玲珑”是早熟、优质小果型西瓜。全生育期</font>
    <font face="Calibri">85</font>
    <font face="宋体">天左右，果实发育天数约</font>
    <font face="Calibri">28</font>
    <font face="宋体">天。植株生长势稳健，第一雌花出现在</font>
    <font face="Calibri">6~8</font>
    <font face="宋体">节，以后每隔</font>
    <font face="Calibri">4~6</font>
    <font face="宋体">片叶又出现一雌花。果实高圆形，果形指数</font>
    <font face="Calibri">1.1</font>
    <font face="宋体">，外观周正，浅绿果皮上覆深绿色齿状条带，中心含糖量</font>
    <font face="Calibri">11.0~12.0%</font>
    <font face="宋体">、果实边部含糖量</font>
    <font face="Calibri">9.0%</font>
    <font face="宋体">，果肉橙黄色，剖面色泽匀、肉质细，口感好，果皮厚度平均为</font>
    <font face="Calibri">0.3~0.5cm</font>
    <font face="宋体">。最大单瓜重</font>
    <font face="Calibri">2.2kg</font>
    <font face="宋体">，平均单瓜重</font>
    <font face="Calibri">1.5~2.0kg</font>
    <font face="宋体">，该品种坐果优良，可坐多茬果，产量表现比“黄小玉”约增产</font>
    <font face="Calibri">13%</font>
    <font face="宋体">，亩产约</font>
    <font face="Calibri">3000</font>
    <font face="宋体">公斤。</font>
    <font face="Calibri">2005</font>
    <font face="宋体">年进行了枯萎病抗性鉴定，结果表明“金玉玲珑”达到了轻抗水平。该品种抗逆性好，可在露地栽培，但保护地栽培更能体现其早熟、优质的特点</font>
    <font face="宋体">。</font>
  </p>
  <p style="text-align: justify;">
    <font face="宋体"></font><br />
  </p>
  <p style="text-align: justify;">
    <font face="宋体"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/news7.png?sign=a43e5db6de48a5031d3bf88d02ba6742&amp;t=1652781946" style="width: 90vw;height: 47vh; margin: 0px auto; display: block;" /></font><br /></p>



  <h1 align="center" style="text-align: center;"><br /></h1>
</div>`
	}, {
		"id": "3",
		"wz": `<h1 align="center" style="text-align: center;">
  <font face="宋体"><strong>小西瓜背后的故事</strong></font>
</h1>
<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg1.png?sign=cb9a35d933dc01c4a57bda660e785716&amp;t=1652781059" style="width: 55vh; " /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg2.png?sign=918946998bf3a3279fc52ef4f0837172&amp;t=1652781082" style="width: 55vh;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg3.png?sign=96f8b960032b2f10c5138673736f7c23&amp;t=1652781101" style="width: 55vh;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg4.png?sign=1ea973b173574e51b3010fcdf50a2611&amp;t=1652781115" style="width: 55vh; " /><br /></p>`
	}],
	"xgyj": [{
		"id": "1",
		"details": `<h2 align="center">


  <font face="微软雅黑"><strong>大棚展示</strong></font>
</h2>



<h1 style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp1.png?sign=c83c8f571b8cd674c6c60f93252d60f0&t=1652794313" style="width: 98vw;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp2.png?sign=b7815bd6e83b45a763e68f6f16488618&t=1652794337" style="width: 98vw;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp3.png?sign=16d16978874c747ac7d814bfc7c7cf2f&t=1652794348" style="width: 98vw;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp4.png?sign=be94207ef6f181c8a6aa6f001cb7b3c6&t=1652794362" style="width: 98vw;" /></h1>
<p align="center">
  <font face="微软雅黑"><strong>△ 精耕细作</strong></font>
</p>



<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp5.png?sign=9b3126605dd175d6072aaa9c82f81245&t=1652794371" style="width: 98vw;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp6.png?sign=0c4eb0449f6d5362600b4d74d9cdc523&t=1652794389" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 棚顶吊蔓</strong></font>
</p>



<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp7.png?sign=0b9a2b370fdf567950c02bcd2f944221&t=1652794406" style="width: 98vw;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dp8.png?sign=b57f4546fea0c28746b9874cdb19ce80&t=1652794417" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 晨曦和大棚的风光</strong></font>
</p>



<p style="text-align: center;"><br /></p>`
	}, {
		"id": "2",
		"details": `<h2 align="center">



  <font face="微软雅黑"><strong>吊蔓展示</strong></font>
</h2>



<h2 align="center"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dm1.png?sign=2633ee9b38796ecd7ed2cc989e93b65d&t=1652794606" style="width: 98vw;" /></h2>
<p align="center">
  <font face="微软雅黑"><strong>△ 间隔均匀，受光均衡</strong></font>
</p>
<p align="center">
  <font face="微软雅黑"><strong><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dm2.png?sign=8378d57a2121bb5a99a7eef6aa7c742a&t=1652794613" style="width: 98vw;" /></strong><br /></font>
</p>





<p align="center">
  <font face="微软雅黑"><strong>△ 瓜型也相当规整统一</strong></font>
</p>
<p align="center">
  <font face="微软雅黑"><strong><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dm3.png?sign=2be224289b344a4bf5ae4f4662d65d5c&t=1652794631" style="width: 98vw;" /></strong></font>
</p>
<p align="center">
  <font face="微软雅黑"><strong>△ 植株的分布</strong></font>
</p>
<p align="center">
  <font face="微软雅黑"><br /></font>
</p>



<p style="text-align: center; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;" align="center"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dm4.png?sign=8c4544245b9bc081edff2f80b513647f&t=1652794647" style="width: 98vw;" /><br /></p>





<p align="center">
  <font face="微软雅黑"><strong>△ 金玉玲珑</strong></font>
</p>
<p align="center">
  <font face="微软雅黑"><strong><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dm5.png?sign=6df5be6cd6c915d9df41f2ee96626932&t=1652794656" style="width: 98vw;" /></strong><br /></font>
</p>





<p align="center">
  <font face="微软雅黑"><strong>△ 硕果累累</strong></font>
</p>



<p align="center"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/dm6.png?sign=8516dbdc80f101d027b7401abe7242bc&t=1652794665" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 硕果累累</strong></font>
</p>



<p align="center"><br /></p>`
	}, {
		"id": "3",
		"details": `<h2 align="center">




  <font face="微软雅黑"><strong>花苗展示</strong></font>
</h2>



<h2 align="center"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/hm1.png?sign=440c95f842dc0fd11b4c82a1dd18ae66&t=1652795162" style="width: 98vw;" /></h2>
<p align="center">
  <font face="微软雅黑"><strong>△ 种子</strong></font>
</p>



<p align="center"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/hm2.png?sign=b8d309ffc336db35709b776ea9cc8d8f&t=1652795184" style="width: 98vw;" /><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/hm3.png?sign=6d29c2775a627b99b02068e1ec299196&t=1652795196" style="font-size: 14.4px; width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 育苗</strong></font>
</p>



<p align="center"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/hm4.png?sign=fe2c63dd4542d88cb3e807cc89331a94&t=1652795207" style="width: 98vw;" /></p>
<p align="center"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/hm5.png?sign=dab8e564c66735a19eb48a9237fc9141&t=1652795216" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 雄花</strong></font>
</p>
<p align="center">
  <font face="微软雅黑"><strong><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/hm6.png?sign=e5af15e19267e694d69a7a86124bf16b&t=1652795227" style="width: 98vw;" /></strong><br /></font>
</p>




<p align="center">
  <font face="微软雅黑"><strong>△ 雌花</strong></font>
</p>



<p align="center"><br /></p>`
	}, {
		"id": "4",
		"details": `<h2 align="center" style="text-align: center;">
  <font face="微软雅黑"><strong>收获展示</strong></font>
</h2>



<h2 align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/sh1.png?sign=a6a274df13789428dee6cfa00c98dd26&t=1652795396" style="width: 98vw;" /></h2>
<p align="center" style="text-align: center;">
  <font face="微软雅黑"><strong>△ “美颜”的集中包装</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/sh2.png?sign=8bf41d86e67bbebb917b1ee332a7380d&t=1652795411" style="width: 98vw;" /></p>
<p align="center" style="text-align: center;">
  <font face="微软雅黑"><strong>△ “美颜”的集中包装</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/sh3.png?sign=d0e1d8ba8b5ccb7237a92dcdfa15fe12&t=1652795421" style="width: 98vw;" /></p>
<p align="center" style="text-align: center;">
  <font face="微软雅黑"><strong>△ 集中运输</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/sh4.png?sign=d0d67715b7d2919c61461f18df3e75c1&t=1652795433" style="width: 98vw;" /></p>
<p align="center" style="text-align: center;">
  <font face="微软雅黑"><strong>△ 采摘</strong></font>
</p>



<p align="center"><br /></p>`
	}, {
		"id": "5",
		"details": `<h2 align="center">

  <font face="微软雅黑"><strong>西瓜掠影</strong></font>
</h2>



<h2 align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg-1.png?sign=230ec30bad3a5a7c80b2d4fceb4c37d2&t=1652793559" style="width: 98vw;" /></h2>
<p align="center">
  <font face="微软雅黑"><strong>△ 色泽清丽</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg-2.png?sign=653ab8fa8fd666fb7ebee08f6e6a38de&t=1652793591" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 爆汁</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xs-3.png?sign=8ef394a12f793018937b7f2afd4be1c9&t=1652793608" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 沐浴在崖城阳光之下</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg-4.png?sign=517bd563208a548181e98bddfb4edb6d&t=1652793624" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ “西瓜迎春花篮”</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg5.png?sign=8aa29b0662bcb8b3ecdb96fa96b2cc5c&t=1652793635" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 莹润如玉</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg6.png?sign=a3c686fa7794f668bde7b90a0ca3416a&t=1652793645" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 收获美丽</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg7.png?sign=857b14a54936512b3404dd23d5106a16&t=1652793656" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 凝成霞光，钟灵毓秀</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg8.png?sign=597c3d282067fd006ffeacddc13de9c5&t=1652793669" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 是可以食用的“美玉”</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg9.png?sign=1730adb44dc4a9f41186191c3e92aae7&t=1652793695" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 一张证件照</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg10.png?sign=165346b70398f6c5922695af5f880d06&t=1652793706" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 果型均匀，排布如“阅兵仪式”</strong></font>
</p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/xg11.png?sign=3174501ab1cfcb05e76f0b2631d096e8&t=1652793716" style="width: 98vw;" /></p>
<p align="center">
  <font face="微软雅黑"><strong>△ 不是调色盘，是彩色西瓜大合影</strong></font>
</p>`
	}],
	"forum": [{
		"id": "1",
		"title": "【大棚技术】大棚放风的科学步骤",
		"zz": "《北方蔬菜报》",
		"writer": "技术流瓜农",
		"article": `<div style="padding:10px"><h2 align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/ltdp1.png?sign=72be2824fe57150e775af877dba2e95f&amp;t=1652805811" style="width: 94vw;" /></h2>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">说到放风，大部分种植户是上午棚室温度上升到</font><font face="Calibri">30</font><font face="宋体">℃以上时，一次性拉开风口，等下午温度降低时，再一次性关闭放风口。</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">其实，这种做法是不科学的，放风不科学，直接影响蔬菜的产量。那么，如何科学放风呢？我们提倡分次放风，分次关风。</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">上午第一次放风是在拉开草苫一小时，大约是在</font><font face="Calibri">9</font><font face="宋体">：</font><font face="Calibri">00</font><font face="宋体">—</font><font face="Calibri">9</font><font face="宋体">：</font><font face="Calibri">30</font><font face="宋体">时，在保证放风后棚内温度不急剧下降的前提下，将放风口拉开</font><font face="Calibri">5</font><font face="宋体">厘米左右，开小口通风。此时正是棚内二氧化碳缺乏的时间，第一次放风不仅可以排除棚内的湿气，还可以及时给棚内补充二氧化碳，保证棚内蔬菜进行正常光合作用。这次放风尤为重要，是决定棚内蔬菜产量高低的关键，因为若不及时放风，棚内二氧化碳浓度不够，蔬菜不能进行光合作用，哪会有产量。</font></span></p>



<p align="center" style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/ltdp2.png?sign=a94ff8988f2328d5dfc433dc592b16a4&amp;t=1652805857" style="width: 94vw;" /></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">第二次放风是在中午前后，也就是在棚温达到</font><font face="Calibri">33</font><font face="宋体">℃左右时再拉大放风口，因为这时棚内的高温会加速水分蒸发，通过放风排除湿气，利于控制棚内的湿度，不利于病害发生。一般来说，这次放风时放风口拉开</font><font face="Calibri">15</font><font face="宋体">厘米左右，保证棚内温度不超过</font><font face="Calibri">30</font><font face="宋体">℃为宜。</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">关闭放风口时，也是分两次进行。拿茄子来说，第一次关风是在棚内气温降低到</font><font face="Calibri">22</font><font face="宋体">℃时将通风口关小，第一次关闭</font><font face="Calibri">10</font><font face="宋体">厘米左右；查看棚内气温降低到</font><font face="Calibri">20</font><font face="宋体">℃时，再进行第二次也就是把通风口完全关闭。</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">这种多次放风、多次关风的方式，能更好地调节温度，比</font><font face="宋体">“一开一闭”的通风方式更有利于蔬菜的生长，并且还能有效降低棚内的湿度，减少病害的侵染和发生。</font></span></p>



<p align="center"><br /></p></div>`
	}, {
		"id": "2",
		"title": "【瓜农故事】小小西瓜苗承载产业振兴大梦想",
		"writer": "爱吃瓜的猹",
		"zz": "“西瓜世界”",
		"article": `<div style="padding: 10px"><h1 style="text-align: center; ">
  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt1.png?sign=e938f0482a02b72a5c845370fa6453ae&amp;t=1652806720" style="width: 94vw;" /></h1>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">2022年1月19日，在砀山县程庄镇百思农果蔬种植专业合作社，一排排大棚整齐壮观。记者走进西瓜苗智能温棚，一股湿热空气扑面而来。戴着口罩的工人散布在苗床间，两三人一组，有的忙着掐芯、整苗、接穗，有的忙着为晾晒过的瓜苗盖膜，一派繁忙景象。</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">大棚的主人叫魏瑾，今年</font><font face="宋体">26岁，她一边指挥工人干活一边告诉记者：“眼下正是西瓜育苗的重要时期，瓜苗及时定植，才能确保农户增产增收。”</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">百思农果蔬种植专业合作社育苗基地共有</font><font face="宋体">6座温室大棚，占地50多亩。“现在育的瓜苗都是有订单的，客户先付一半定金，我们培育他们指定品种的瓜苗，交苗时客户再付另外一半定金。一个棚能育60万棵瓜苗，今年我们一共开了4个棚，订单有270万棵瓜苗左右。现在看到的就是客户和附近农户在我们这儿定植的西瓜苗，等到2月份就可以出苗。我们实行订单育苗的模式，好处就是保证苗厂不剩苗，农户的地也不会空着等不到苗。”</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">优质的瓜苗才能种出优质的西瓜。</font><font face="宋体">“我们培育的瓜苗全部要求是‘三叶一心’的标准苗，农户拿到苗后就可以直接种植了。每年能育三茬苗，我们现在的主要工作就是育接穗，给农户嫁接好养护好。”魏瑾说。</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">记者看到，在不同的苗棚里，工人的分工也不相同，有的负责给南瓜苗</font><font face="宋体">“摘耳朵”，有的负责为西瓜接穗“摘帽”，为后期瓜苗嫁接作充足准备。集约化生产育苗方式以及大量的订单为附近村民提供了充足的就业岗位。今年49岁的许瑞玲正忙着给瓜苗浇水，她笑着对记者说：“我家就住在附近，已经在基地干了七八年了，干活不累，一个月能收入4000多块钱，挺满意的！”</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">在另一个苗棚里，一箱箱摆放整齐的西瓜接穗即将装车运往萧县。萧县黄口镇杜集村的西瓜种植户杜广伟告诉记者，他今年定了</font><font face="宋体">3万棵瓜苗，看中的正是合作社育苗基地接穗利用率高、成活率好的品种优势，以及源源不断的栽植技术指导。“我们那边的西瓜种植面积也比较大，之前买过他们的种子，觉得品质很不错，今年直接就引穗了。他们的苗子十分抢手，这不，我定的苗都排到2月4号了。”</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">小小的西瓜苗承载了产业振兴的大梦想。如今，百思农果蔬种植专业合作社育苗基地已经形成集约化育苗方式，提高优质种苗供应，为当地西瓜种植产业发展形成合力，在育苗发展接续果实增产的同时，带动村民走上育苗产业致富之路，也为乡村振兴的发展鼓足了后劲。</font></span></p>
<p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">“下一步，我们准备扩大西瓜种植面积，为附近更多的农户提供高品质的种子以及技术支持、就业岗位等，打响我们自己的品牌，助力乡村振兴。”魏瑾说。</font></span></p></div>`
	}, {
		"id": "3",
		"title": "【农业投资】新手必读-大棚瓜菜的利润与成本分析",
		"writer": "吃瓜群众只想暴富",
		"zz": "“西瓜世界”",
		"article": `<div style="padding: 10px">
  <h1 style="text-align: center; "><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt2.png?sign=159140b01194515042762b22edcc5458&amp;t=1652807140" style="width: 94vw; margin: 0px auto; display: block;" /></h1>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">在现在的日常生活中，反季蔬菜可是越来越多了，像在寒冷的冬天过冬的蔬菜早已不再是单一的大白菜，想吃什么超市里都有，如果想吃个西瓜也是可以的而且很甜，这些蔬菜水果都是在大棚里种植的。所以现在就有很多的大棚种植户，那么这些蔬菜大棚种植的利润有是多少呢？大棚种植蔬菜的成本和利润这是和大棚的建设与平时的维护，还有种植管理所需要的农资来决定的。每个地方也是不一样的，种植大棚也不能盲目，下面就跟着小编来大体了解种植大棚的利润吧！</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">一</font></span></b><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">、</font></span></b><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">种植大棚蔬菜的利润和成本</font></span></b></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">通常种植蔬菜大棚每一亩地需要的大棚的骨架要</font><font face="Calibri">5500</font><font face="宋体">块钱左右，既能节省成本又能使大棚寿命得延长的办法就是用的菱镁的复合型材料制造大棚的基本框架以及使用塑料纸。这样做还能有利于大棚的日常维护。塑料纸需要每年换一次，这样的大棚大概能使用五年。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">如果按每亩地算，每年蔬菜的种苗成本，农药化肥成本等大约有七百左右，租地成本按每年八百左右。综合来算种植大棚里的蔬菜初期每亩地大约需要七千元，蔬菜大棚可以用五年，平均每年也就是两千五百元左右。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">种植大棚蔬菜利润能达到</font><font face="Calibri">150%</font><font face="宋体">到</font><font face="Calibri">250%</font><font face="宋体">左右，每年能丰收两三季蔬菜，如果种植我们常见的一般蔬菜，种植一到两季菜估计就能收回一开始建造大棚的成本，也就是说种植蔬菜一年就能回本，以后每年所需要花费的成本就只有塑料纸钱。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt3.png?sign=899f61133f7a9acf6e1ca06914ac5b65&amp;t=1652807182" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">当然种植大棚的蔬菜需要技术，把棚蔬菜种好才能挣更多的钱达到理想收益，种大棚蔬菜是一项系统技术，在整个过程中都需要菜农自己来掌握。如果想熟练的运用种大棚的技术，必须渐渐累积种大棚作物的各种具体的操作以及管理事项。小编只是对相关资料进行梳理，让朋友们更加容易理解，希望能给你们带来帮助。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">建造蔬菜大棚的成本是菜农们一开始最关心的问题，首先得了解要建造的大棚属于什么类型，还要了解在建造过程中需要的辅助材料，整体梳理一遍会提高建造大棚的效率，也会节省一些不必要的开支。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-indent: 21pt; text-align: center; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;" align="center"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">蔬菜大棚的类型以及成本</font></span></b></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">六米装配式的钢架大棚</font></span></b></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">这种大棚已经被应用了很久，它是用直径</font><font face="Calibri">2.2cm</font><font face="宋体">与</font><font face="Calibri">0.12cm</font><font face="宋体">厚的渡了锌的薄钢管为骨架的钢架大棚，大棚宽</font><font face="Calibri">6m</font><font face="宋体">，高</font><font face="Calibri">2.2m-2.5m</font><font face="宋体">，肩高是</font><font face="Calibri">1.2m</font><font face="宋体">，土地的利用率是百分之八十左右，这类大棚的寿命能长达</font><font face="Calibri">10</font><font face="宋体">年以上，每平米的成本大约是</font><font face="Calibri">10</font><font face="宋体">元到</font><font face="Calibri">30</font><font face="宋体">元，每亩的建设制作的成本大约需要七千到两万元。这种大棚适合种植花卉，蔬菜。缺点不够宽，管理起来效率比较低，冬季的时候比较冷保温效果不好。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt4.png?sign=e646754bdf799681807e4ddf1c4311c7&amp;t=1652807226" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;" align="justify"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">竹架大棚</font></span></b></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">这种大棚用的也很多。大棚宽五米到六米。高大约两米到</font><font face="Calibri">3</font><font face="宋体">米</font><font face="Calibri">2</font><font face="宋体">之间。侧高有一米到</font><font face="Calibri">1</font><font face="宋体">米</font><font face="Calibri">2</font><font face="宋体">之间。拱杆之间的距离大约有</font><font face="Calibri">1m</font><font face="宋体">到</font><font face="Calibri">1.1m</font><font face="宋体">。这里大棚的优点是成本低，材料简单方便，建造起来很容易。每亩的成本大约有</font><font face="Calibri">3000</font><font face="宋体">块钱。但是它也有缺点，大棚内的柱子太多，很容易遮挡住光线，管理起来不方便，而且这类大棚很容易坍塌，遇到恶劣天气的时候很容易被毁。其中在老家有一种大棚叫</font><font face="Calibri">"</font><font face="宋体">滚地龙</font><font face="Calibri">"</font><font face="宋体">，宽度约</font><font face="Calibri">4m</font><font face="宋体">到</font><font face="Calibri">6m</font><font face="宋体">，塑料膜是一片式的，直接覆盖到底。比一般竹的大棚更加节省本钱，适合种植在地上生长的蔬菜水果。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt5.png?sign=d0e3ca8be955f3109165293821f2b01c&amp;t=1652807274" style="margin: 0px auto; display: block; width: 94vw;" />
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">钢竹混合大棚</font></span></b></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">这种大棚的结构与竹架大棚是相同的，只是拱杆换成了竹竿，这样节省了成本，操作简单，这种大棚使用起来比竹架大棚好用但不及钢架大棚。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="Calibri">8m</font><font face="宋体">提高型钢架大棚</font></span></b></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">这种大棚在一般钢架大棚的基础上增加了高与宽，更有利于通风，大棚内的空间也增加了不少，冬季保温效果得到了改善。其骨架是由直径</font><font face="Calibri">2.8cm-3.2cm</font><font face="宋体">，厚</font><font face="Calibri">0.15cm</font><font face="宋体">的镀锌钢管构成，高</font><font face="Calibri">3.2m</font><font face="宋体">到</font><font face="Calibri">3.5m</font><font face="宋体">，肩高</font><font face="Calibri">1.8m</font><font face="宋体">，很适合种植高的或者需要搭架的作物。它的每平米的成本是</font><font face="Calibri">20</font><font face="宋体">元到</font><font face="Calibri">45</font><font face="宋体">元之间，每亩的成本大约</font><font face="Calibri">1.5w-3w</font><font face="宋体">左右。主要用于农业的示范园或者被有经济实力的种植户使用。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt6.png?sign=dbe23fbec657044fbd2d31e3a18d9a82&amp;t=1652807309" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">连栋大棚</font></span></b></p>
  <p style="text-indent: 21pt; text-align: center; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;" align="center"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">连栋的大棚有一般连栋大棚与简易竹架的连栋大棚，它的空间很大，土地使用也是很高的，但是成本是很低廉的。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt7.png?sign=dbafd125994e658018ba06c3ab2de564&amp;t=1652807344" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">二</font></span></b><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">、</font></span></b><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">大棚的覆盖材料</font></span></b></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">普通膜：以</font><font face="Calibri">PE</font><font face="宋体">或</font><font face="Calibri">PVC</font><font face="宋体">为原材料，厚度约</font><font face="Calibri">0.01cm</font><font face="宋体">，能够使用半年。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">功能多的长寿膜：在原材质的基础上加入了防老化的材质和一些表面活性材料。宽大约有七米半，厚度是</font><font face="Calibri">0.006cm</font><font face="宋体">，它的使用寿命是普通膜的一倍。保温效果比较好，而且这种膜的表面不容易结水滴。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">草被：这种膜老百姓都很熟悉。早期的时候老百姓就会用稻草编织成草被子，冬季的时候给蔬菜或者是瓜果保温，可见老百姓的智慧也是无穷大的。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">PE</font><font face="宋体">高发泡软片：白色的，很多气泡的塑料软片。大约有一米。厚度是四分米到五分米之间。能够卷起来，它的保温效果和草被子的保温效果差不多。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">无纺布：无纺布是一种涤纶长丝，没有经过纺织，类似于布，有黑白两种颜色。有不同的密度，还有不同的厚度。除了保温效果挺好以外，还可以当作遮阳网来使用。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">遮阳网：是一种用塑料纺织而成的网。有黑色，还有灰色，近几年在工地上还有绿色。它的密度有不同的规格，主要适用于夏天遮挡太阳。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;" align="justify"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">三</font></span></b><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">、</font></span></b><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">蔬菜大棚的方向</font></span></b></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">蔬菜大棚应该建设在水源充足，灌溉方便，地下水位低的地方，而且土壤质量也很重要，土质没有经过污染要肥沃。一般大棚的方向是南北走向。它的排风口建设在东西两边。不要以为是随便建造的，这样做是有优点的。有利于降低大棚内的湿度，有利于采光，进行光合作用，帮助植物生长。在冬季的时候，增加换气量，防止温度降低过快。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lt8.png?sign=c8e4556d33f266ac4289a168f4be6b61&amp;t=1652807375" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">现在市场上越来越需要反季蔬菜，种植大棚蔬菜可以说已经成为了一种趋势。希望小编今天的总结能对各位有所帮助，喜欢的朋友可以点击关注，小编每天都会分享一些种植的或养殖的技术方面的知识哦！</font></span></p>



  <p style="text-align: center; "><br /></p>
</div>`
	}, {
		"id": "4",
		"title": "【三天学会种西瓜】催芽与播种",
		"writer": "我很会种西瓜 ",
		"zz": "“西瓜世界”",
		"article": `<div style="padding: 10px">
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;">&nbsp;<font face="宋体">一、催芽</font></span></b></p>
  <p style="text-indent: 21pt; margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">在催芽之前，首先进行种子消毒和浸种。</font></span></p>
  <p style="text-indent: 21pt; margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">1</font><font face="宋体">、消毒。可以用</font><font face="Calibri">2%-4%</font><font face="宋体">的漂白粉溶液将西瓜种浸泡半个小时，捞出后用清水洗净，可杀死种皮细菌。用</font><font face="Calibri">50%</font><font face="宋体">多菌灵可湿性粉剂浸泡一小时，可防止真菌病害。还可以选择晴朗无风天气将种子摊在席子或纸等物体上暴晒。暴晒除有一定的杀菌作用外，还可以促进种子后熟。增强种子活力，提高种子的发芽势和发芽率。</font></span></p>
  <p style="text-indent: 21pt; margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">2</font><font face="宋体">、浸种。浸种的目的是促使种皮和胚对水分吸收，软化种皮，提高种子的呼吸强度，促进养分分解，加速发芽。种皮厚的可以时间长一些，皮薄的小粒种子可以时间短一些。主要浸种方法有：（</font><font face="Calibri">1</font><font face="宋体">）</font><font face="Calibri">55</font><font face="宋体">度温水浸种，用开水两份对凉水一份，调制</font><font face="Calibri">55</font><font face="宋体">度的温水，边浸边搅拌</font><font face="Calibri">15</font><font face="宋体">分钟，自然冷却后，在浸泡</font><font face="Calibri">4-6</font><font face="宋体">个小时即可。（</font><font face="Calibri">2</font><font face="宋体">）恒温浸种。用</font><font face="Calibri">25-30</font><font face="宋体">度的温水，浸泡</font><font face="Calibri">6-8</font><font face="宋体">小时。要注意浸种完毕后要把种子在清水中洗几遍，洗去种子表皮粘液，有利于种子萌发。</font></span></p>
  <p style="text-indent: 21pt; margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">催芽一般用温箱，一般温度设置为</font><font face="Calibri">28-32</font><font face="宋体">度，把泡好的种子用毛巾搓去表面的水分，把种子铺平，用半干半湿的毛巾包住，外面套上塑料袋，以防止温箱里的风把毛巾吹干。一般</font><font face="Calibri">24</font><font face="宋体">小时开始出芽，</font><font face="Calibri">2-3</font><font face="宋体">天即可基本出齐。</font></span></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">二、播种</font></span></b></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">当西瓜种子露出白尖，就可以播种了。</font> <font face="宋体">播种前应浇足底水，最好选择晴天上午播种。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz1.png?sign=d9cac585e28e365e3cc80a6926aeb8f2&amp;t=1652807725" style="width: 94vw; margin: 0px auto; display: block;" />




  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">播种时把种子平放在穴盘或营养钵上，边播籽边覆土。覆土要细，最好过筛，一般覆一公分左右，大籽要稍厚一些。这个环节最为重要，覆土过浅容易带帽，过深出苗迟缓，苗弱，甚至烂种。播种后不再浇水，保持土壤疏松，然后在土面上覆一层薄膜。防止水分蒸发和鼠害。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz2.png?sign=26b5af330d839731b6447b06cc041829&amp;t=1652807797" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-align: center; "><br /></p>
</div>`
	}, {
		"title": "【生理病害】化瓜的原因",
		"writer": "西瓜西施",
		"id": "5",
		"zz": "“西瓜世界”",
		"article": `<div style="padding: 10px">
  <p style="text-align: center; "><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz3.png?sign=23a2e3ccc194ae2436ecc72443d3a637&amp;t=1652807983" style="width: 192px; height: 255px; margin: 0px auto; display: block;" /></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">化瓜是西瓜生产中的重要问题。引起化瓜的原因很多，可综合为内因和外因两类。</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">一、化瓜的内因</font> </span></b><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">1</font><font face="宋体">、没有授粉或受精。西瓜为雌雄同株异花，如果在阴雨天就不能授粉，或虽已授粉而不能受精。如花粉不发芽或花粉管生长不正常时，均不能完成受精。</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">2</font><font face="宋体">、花器畸形。雌花或雄花中的任何一方发育不正常，如柱头过短、无蜜腺、花药中无花粉或雌蕊退化等均能引起化瓜。</font></span></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">3</font><font face="宋体">、营养生长过强或过弱。西瓜蔓、叶生长过旺或过弱，使营养物质分配不平衡，以致发生器官之间的竞争，其结果均不利于果实的生长发育。实践证明，以营养生长中庸偏上最有利于果实的生长。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz4.png?sign=1912ea6008619011c86a1cf734bd8463&amp;t=1652808029" style="width: 317px; height: 422px; margin: 0px auto; display: block;" />
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><b><span style="font-family:宋体;font-weight:bold;font-size:10.5000pt;"><font face="宋体">二、化瓜的外因</font></span></b><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-align: center; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;" align="center"><span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">1</font><font face="宋体">、水分不足或过多。开花期间土壤水分不足容易引起落花。水分过多造成蔓、叶徒长，使子房营养不良而化瓜。降雨影响授粉也易引起落花和化瓜。</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">2</font><font face="宋体">、温度不适宜。温度过高过低影响花粉管的伸长，因而影响受精，引起落花。</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">3</font><font face="宋体">、光照不足及栽培密度过大。在开花时，由于光照不足常常造成子房内养分暂时缺乏，而引起“饥饿”性化瓜。栽培密度过大，连阴寡照，通风不良，造成郁闭，架形不合理，不利于光合作用，同化产物少，容易造成化瓜。缺水缺肥或因施肥不当造成微量元素缺乏，也影响光合作用。</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">4</font><font face="宋体">、二氧化碳</font><font face="Calibri">(CO2)</font><font face="宋体">浓度低瓜类蔬菜一般对二氧化碳气体浓度变化非常敏感，如果棚室内二氧化碳浓度过低，就容易化瓜。</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="Calibri">5</font><font face="宋体">、病虫危害严重 。霜霉病、细菌性角斑病、炭疽病、白粉病、黑星病等，都会直接危害叶片，造成叶片坏死，严重者造成全叶或整株叶片干枯，无法进行光合作用而化瓜。蚜虫、茶黄螨、白粉虱等害虫通过吸取瓜类蔬菜叶片汁液和污染叶片，破坏光合作用，造成营养不良而化瓜。</font></span></p>



  <p style="text-align: center; "><br /></p>
</div>`
	}, {
		"title": "【西瓜栽培研究】幼苗黄叶问题",
		"writer": "技术流瓜农 ",
		"id": "6",
		"zz": "“西瓜世界”",
		"article": `<div style="padding: 10px">

  <p style="text-indent: 21pt; text-align: justify; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">上午，农科所的时老师打过来电话，说他育的西瓜苗叶子一直变黄，不知怎么回事。时老师之前是做葡萄栽培的，现在退休了，和朋友搞了几个大棚，栽培礼品西瓜。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz5.png?sign=0f8c30c720eee0df8a64e6a23e456190&amp;t=1652808340" style="width: 94vw; margin: 0px auto; display: block;" /></font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">叶子变黄，我的第一反应是缺肥，因为他说有三个周了，用的直接是田土，没有一点肥料，可看到图片，就感到不对，直接上图。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz6.png?sign=9c1c6b7ef5f0fa9bc3dd588f71cd6802&amp;t=1652808406" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体"></font><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz7.png?sign=b5b0a2ef6897e78a99ab1c9d42ff280f&amp;t=1652808434" style="width: 94vw; margin: 0px auto; display: block;" /></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">这么小的瓜苗，怎么可能缺肥呢，估计根都没扎满。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">西瓜自根苗没有嫁接苗旺盛，如果不是缺肥，就应该是水分和温度的问题。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz8.png?sign=fa5a464ba9f2d4812594c8b140ee88cf&amp;t=1652808488" style="margin: 0px auto; display: block; width: 94vw;" />
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">西瓜苗期，特别是冬季育苗，温度过低或者水分过大，易寒根。寒根后，吸收不了营养，自然发黄。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/tz9.png?sign=81cb789649874a64dd9159f5eb4afb84&amp;t=1652808537" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">我又咨询了几位老师，大家的看法也是如此，现在的黄苗应该就是水分过大，和温度过低造成的，所以立即联系时老师，让他注意温度和湿度。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">上午升温慢，可以放风时稍晚一点，棚里不高于</font><font face="宋体">30度，湿度不大的情况下，不用放。下午可以晚点盖棚，下午的温度降的慢。如果控制好，几天应该就能过来了。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">在瓜菜育苗中，西瓜是相对难的，因为对温度要求高，一不小心，容易毁苗，所以，各位瓜友，一定要慎之又慎。</font></span></p>



  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><br /></span></p>
</div>`
	}, {
		"title": "【学种瓜系列之土肥】瓜田施肥的原则",
		"writer": "瓜田小任",
		"id": "7",
		"zz": "“西瓜世界”",
		"article": `<div style="padding: 10px"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lttz1.png?sign=19b6b50844317da133708ccde15c8c33&amp;t=1652808869" style="width: 94vw; margin: 0px auto; display: block;" /></div>
<div style="padding: 10px">
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">俗话说，庄稼一枝花，全靠粪当家，所以说施肥是西瓜栽培中，非常重要的工作。上一篇我们讲到，西瓜施肥量和土壤肥力，栽培方式，气候变化等都有关系，可具体要遵守哪些原则呢，请往下看。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lttz2.png?sign=1b67cf402cf0d771480899350eab6fe0&amp;t=1652808907" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">瓜田施肥主要有以下原则：</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">其一，要重视有机肥。有机肥来源广泛，品种多，主要包括人粪尿、畜禽粪尿、作物秸秆、绿肥等。其能够疏松土壤，促进根系生长，提高抗病性和根的吸收能力，以缓效的厩肥作基肥，可以供整个生长期吸收。从长期看，有机肥能改善土壤环境，节约化肥用量减少能源消耗和环境污染。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">其二，氮肥要适当。氮元素营养水平直接影响西瓜生长势和产量，但西瓜对氮素营养水平敏感，水平低时长势弱，过量则易发生徒长。有试验表明，在施用有机肥的同时，氮素每亩</font><font face="Calibri">20</font><font face="宋体">公斤标准氮为宜。</font></span></p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/lttz3.png?sign=b3eef2e8b5197d46ad0d6e68b8ceb1dd&amp;t=1652808932" style="width: 94vw; margin: 0px auto; display: block;" />
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">其三，磷肥易早施。磷素营养促进根系生长，促进花芽分化和花蕾发育，提高幼苗的抗寒力，早施有利于发根，增进果实品质。</font></span></p>
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">其四，钾肥促品质。试验表明，钾肥的使用无论是单独或者配合施用，都显著提高西瓜果实的含糖量，改善品质，提高抗病性，从而提高产量。钾肥增加含糖量的原因是，钾能提高蔗糖合成酶的活性而降低酸性蔗糖酶活性，促进蔗糖合成有利于糖的运转和积累。</font></span></p>



  <p style="text-align: center;"><br /></p>
</div>`
	}],
	"pzzs": [{
		"id": "1",
		"name": "朝霞",
		"html": `<h2 style="text-align: center;">
  朝霞——最早熟的彩虹瓜</h2>
<div style="padding: 10px">
  <p style="text-align: left; margin-left: 30px;">【特性】该品种耐低温性好，早熟
  </p>
  <p style="text-align: left; margin-left: 30px;">【口感】果实酥脆多汁，肉质细嫩多汁，口感好
  </p>
  <p style="text-align: left; margin-left: 30px;">【糖度】中心糖含量 12.0-14.0%
  </p>
  <p style="text-align: left; margin-left: 30px;">【果肉】果肉黄中透红
  </p>
  <p style="text-align: left; margin-left: 30px;">【果皮】果皮厚度为 0.4cm 左右
  </p>
  <p style="text-align: left; margin-left: 30px;">【果型】果实高圆形
  </p>
  <p style="text-align: left; margin-left: 30px;">【重量】平均单瓜重1.8-2.5kg
  </p>
  <p style="text-align: left; margin-left: 30px;">【熟期】极早熟、可提前采摘，果实八成熟时口感已很好</p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_zhaoxia.png?sign=79b9c3518763014c29a6ddb69a710290&amp;t=1652772895" style="width: 70vw;" /><br /></p>`
	}, {
		"id": "2",
		"name": "众天红",
		"html": `<h2 style="text-align: center;">
  众天红——小西瓜中的硬皮瓜</h2>
<div style="padding: 10px">
  <p style="text-align: left; margin-left: 30px;">【特性】该品种坐果整齐，商品率高，品质好，较耐运输是其特色
  </p>
  <p style="text-align: left; margin-left: 30px;">【口感】果肉松脆可口而果皮硬度大
  </p>
  <p style="text-align: left; margin-left: 30px;">【糖度】中心糖含量 11.5-13.0%，中边糖梯度小
  </p>
  <p style="text-align: left; margin-left: 30px;">【果肉】果肉浓粉红，口感好
  </p>
  <p style="text-align: left; margin-left: 30px;">【果皮】果肉厚度为 0.4cm 左右
  </p>
  <p style="text-align: left; margin-left: 30px;">【重量】平均单瓜重 1.5-2.8kg
  </p>
  <p style="text-align: left; margin-left: 30px;">【熟期】早熟<br /></p>
</div>
  <p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_zhongtianhong.png?sign=cd36ee6f3b4dd6f534a2bda3a25bb9cb&amp;t=1652773077" style="width: 70vw;" /><br /></p>`
	}, {
		"id": "3",
		"name": "满月",
		"html": `<h2 style="text-align: center;">
  满月——爆汁西瓜</h2>
<div style="padding: 10px">
  <p style="margin-left: 30px; text-align: justify;">【特性】皮韧肉脆，俗称“爆汁”西瓜 </p>
  <p style="margin-left: 30px; text-align: justify;">
    【糖度】果实中心含糖量13%，果实边部含糖量9%以上
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果肉】爽脆多汁
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果皮】果皮厚度平均为0.5厘米
  </p>
  <p style="margin-left: 30px; text-align: justify;">【重量】单瓜重1.5～2.3千克
  </p>
  <p style="margin-left: 30px; text-align: justify;">【熟期】早熟小果型西瓜品种，雌花开放至果实成熟30～32天<br /></p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_manyue.jpg?sign=d91ff578669ebcc85f6ffc04c553ace8&amp;t=1652773226" style="width: 70vw; margin: 0px auto; display: block;" /><br /></p>`
	}, {
		"id": "4",
		"name": "美颜",
		"html": `<h2 style="text-align: center;">
  美颜——瓜美风味好</h2>
<div style="padding: 10px">
  <p style="margin-left: 30px; text-align: justify;">【特性】耐高温是其最大优势
  </p>
  <p style="margin-left: 30px; text-align: justify;">【糖度】果实中心含糖量12.5%～14.5%，果实边部含糖量9.0%～10.0%</p>
  <p style="margin-left: 30px; text-align: justify;">【果肉】果肉红黄双色，口感特别好
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果皮】绿色果皮上覆深绿色齿状条带，果皮厚度平均为0.4厘米
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果型】果实圆形
  </p>
  <p style="margin-left: 30px; text-align: justify;">【重量】单瓜重1.5～2.8千克
  </p>
  <p style="margin-left: 30px; text-align: justify;">【熟期】早熟，生长周期：30～32天<br /></p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_meiyan.jpg?sign=dcc36412b0a16e9be079f700cc83a800&amp;t=1652773359" style="width: 70vw; margin: 0px auto; display: block;" /><br /></p>`
	}, {
		"id": "5",
		"name": "春晖",
		"html": `<h2 style="text-align: center;">
  春晖——橘肉耐高温</h2>
<div style="padding: 10px">
  <p style="margin-left: 30px; text-align: justify;">【糖度】果实中心含糖量12~14%、 果实边部含糖量8.0%
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果肉】果肉浅桔色，肉质脆，口感好 </p>
  <p style="margin-left: 30px; text-align: justify;">
    【果皮】果皮厚度平均为0.5cm
  </p>
  <p style="margin-left: 30px; text-align: justify;">【重量】单瓜重2.0~2.5kg
  </p>
  <p style="margin-left: 30px; text-align: justify;">【熟期】雌花开放至果实成熟29~31天<br /></p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_chunhui.jpg?sign=6730cc69613e3d1acc3dbedcd109917b&amp;t=1652773460" style="width: 70vw; margin: 0px auto; display: block;" /><br /></p>`
	}, {
		"id": "6",
		"name": "众天1293",
		"html": `<h2 style="text-align: center;">
  众天1293——椭圆易装箱</h2>
<div style="padding: 10px">
  <p style="margin-left: 30px; text-align: justify;">【特性】田间坐果整齐，果型好
  </p>
  <p style="margin-left: 30px; text-align: justify;">【甜度】中心糖含量13.0-14.0%。中边糖梯度小</p>
  <p style="margin-left: 30px; text-align: justify;">
    【果肉】果肉松脆可口
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果皮】果皮硬度大，耐运输，果皮厚度为0.4cm左右
  </p>
  <p style="margin-left: 30px; text-align: justify;">【重量】平均单瓜重1.5-2.8kg
  </p>
  <p style="margin-left: 30px; text-align: justify;">【熟期】早熟<br /></p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_zhongtian1293.jpg?sign=74735c149a7928411776ddf3a17f6a94&amp;t=1652773565" style="width: 70vw; margin: 0px auto; display: block;" /><br /></p>`
	}, {
		"id": "7",
		"name": "众天6211",
		"html": `<h2 style="text-align: center;">
  众天6211——耐高温、色艳丽</h2>
<div style="padding: 10px">
  <p style="margin-left: 30px; text-align: justify;">【特性】皮色艳丽是其最大特色</p>
  <p style="margin-left: 30px; text-align: justify;">【糖度】果实中心含糖量 11.0-13.0%、果实边部含糖量 8.0%
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果肉】口感较好，果肉橙红色
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果皮】果皮厚度平均为 0.5cm</p>
  <p style="margin-left: 30px; text-align: justify;">【重量】单瓜重1.3-2.5kg</p>
  <p style="margin-left: 30px; text-align: justify;">【熟期】早熟小果型西瓜品种，八成熟即可采收<br /></p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_zhongtian6211.png?sign=349fa1e9e484af5369cc7e7b10063009&amp;t=1652773674" style="width: 70vw; margin: 0px auto; display: block;" /><br /></p>`
	}, {
		"id": "8",
		"name": "玉琢",
		"html": `<h2 style="text-align: center;">
  玉琢——黄肉中的甜品瓜</h2>
<div style="padding: 10px">
  <p style="margin-left: 30px; text-align: justify;">【糖度】果实中心含糖量12.0%以上 果实边部含糖量9.0%以上，黄肉品种中属于高糖品种
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果肉】肉质脆
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果皮】果皮厚度平均为0.5厘米
  </p>
  <p style="margin-left: 30px; text-align: justify;">【重量】单瓜重1.6～2.5千克
  </p>
  <p style="margin-left: 30px; text-align: justify;">【熟期】雌花开放至果实成熟30～35天<br /></p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_yuzhuo.jpg?sign=c3beb07566305a29fe83851b381e4400&amp;t=1652773764" style="width: 70vw; margin: 0px auto; display: block;" /><br /></p>`
	}, {
		"id": "9",
		"name": "众天2013",
		"html": `<h2 style="text-align: center;">
  众天2013—绿皮耐高温</h2>
<div style="padding: 10px">
  <p style="margin-left: 30px; text-align: justify;">【特性】该品种耐高温性好，可越夏栽培
  </p>
  <p style="margin-left: 30px; text-align: justify;">【糖度】中心含糖量含量12.0~14.0%，中边糖梯度小
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果肉】果肉红，口感脆好
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果皮】绿果皮上覆绿色网条带，果皮厚度为 0.5cm
  </p>
  <p style="margin-left: 30px; text-align: justify;">【果型】果实椭圆形</p>
  <p style="margin-left: 30px; text-align: justify;">【重量】平均单瓜重 1.8~2.5kg
  </p>
  <p style="margin-left: 30px; text-align: justify;">【熟期】早熟小果型西瓜<br /></p>
</div>
<p style="text-align: center;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/index_zhongtian2013.png?sign=815a903c5371295b1f3965500233b4ea&amp;t=1652773866" style="width: 70vw; margin: 0px auto; display: block;" /><br /></p>`
	}],
	"gg": [{
		"id": "1",
		"html": `<div style="padding:10px; "><h1 style="text-align: center; padding: 10px;"><span style="font-size: 32px;">种植科普</span></h1>
		<hr />
		<h2 style="line-height: 150%; padding: 10px;"><span style="color: rgb(207, 19, 34); font-size: 24px;">1、大棚、日光温室冬春茬栽培技术研究</span>
		</h2>
		<p style="line-height: 150%;">
			（1）合理安排栽培季节：&nbsp;日光温室的保温性能最好，冬春茬华北地区小果型西瓜的播种期可选择在12月中下旬，一般大棚的播期比日光温室晚约30天，但是有些小果型西瓜大棚栽培，由于采用多层覆盖（5层甚至5层以上），故其播种期比日光温室稍晚甚至相同。在生产中有的瓜农为了抢早增效，常设法另外增加一些措施（如人工加温）再把播种期相应提早，也获得了成功，如山东冬暖棚最早播期可选在11月初。但是播种期不宜盲目提早，如果相应的保温措施跟不上，愈提早就愈容易失败。
		</p>
		<p style="line-height: 150%;">
			（2）选择品种：由于大棚、日光温室栽培是高效农业，所以大多选择优质的小果型西瓜品种。另外这一季栽培的主要目标是早熟争高效，因此选用的品种应是耐低温、耐弱光的早熟优质品种，如金玉玲珑、小兰、特小凤等。</p>
		<p style="line-height: 150%;">（3）育苗：采用棚内扣小拱棚的温床育苗，有条件的最好使用电热温床育苗。培育苗龄30~35天，三叶一心的适龄大苗，因为较大的苗有利于早熟。</p>
		<p style="line-height: 150%;">（4）定植：定植与大棚内当时地温有密切关系，应提前扣棚，以利于提高棚内温度，使定植时10厘米地温稳定在15度以上。</p>
		<p style="line-height: 150%;">
			定植前应及早做好整地、施肥、作畦工作。定植前10~15天先浇透水，地表稍干后即可整地。土壤在前作物收获后及时深翻30厘米，基肥以猪粪、牛粪、羊粪等有机肥为主，每亩施5000千克，过磷酸钙40~50千克，复合肥150千克。先用2/3翻地时撒施，施后整平，按1米垄距做高20~25厘米、宽70厘米的垄（呈龟背型高畦），垄底施入剩余的1/3基肥，再铺上地膜。为便于采光，南北走向大棚顺棚方向作畦，东西走向大棚要横着棚向作畦。栽苗前，用制钵器按一定距离在高垄中央破膜打孔，孔内浇透水，将幼苗栽到孔内，挖定植坑时尽量保护地膜的完整，定植后的钵面与地面持平，不要过低（地温低影响根系发育）或过高（根系土壤易干燥）。定植后要清洁地膜上的泥土，以便充分发挥其透光增温作用。每垄（畦）栽一行，单蔓整枝时株距（孔距）为33~40厘米，双蔓整枝时株距按40~45厘米。单蔓整枝每亩约1800棵，双蔓整枝每亩保苗1400棵。通常大棚高畦只铺地膜即可，但有时在定植后的短期内还加盖小棚，以利保温，促进缓苗，促进幼苗的迅速生长。瓜苗移栽后要防止僵苗：如果气温偏低，土温长期低于15度，容易产生沤根现象，这时要采取措施适时加温；如果因水分不适宜造成幼苗停滞不长，则要视具体情况采取相应措施，若渍，要多中耕，若旱，要少量多次浇水。
		</p>
		<p style="line-height: 150%;"><span style="font-size: 12pt; font-family: 宋体;">（</span><span
				style="font-size: 12pt; font-family: Calibri;">5）棚内温、湿度的调节：&nbsp;小果型西瓜在整个生育期内最适宜的生长发育温度是25~30℃，但在不同生长发育阶段对温度要求也不同。定植后，白天大棚保持气温27~30℃，夜间不低于20℃，地温27℃左右，缓苗后注意通风降温。开花前营养生长期保持白天气温25~30℃，夜间不低于15℃，地温25℃左右。开花期白天27~30℃，夜间15~18℃。果实膨大期白天保持27~30℃，夜间15~20℃。成熟期白天28~30℃，夜间不低于15℃，地温20~23℃。营养生长期昼夜温差要求10~13℃，坐果后要求15℃。夜间温度过高容易徒长，对糖分积累不利，影响品质。</span>
		</p>
		<p style="line-height: 150%;"><span
				style="font-size: 12pt; font-family: Calibri;">&nbsp;&nbsp;&nbsp;&nbsp;适于小果型西瓜生长的空气相对湿度为50~60%。而大棚内白天60%，夜70%~80%也能使小果型西瓜正常生长。苗期及营养生长期对较高、</span>较低的空气湿度适应性较强，但开花坐果后，尤其进入膨瓜期，对空气湿度反应敏感，主要在植株生长中后期，空气湿度过大，会推迟开花期，造成茎叶徒长，以及引起病害的发生。当棚内温度和湿度发生矛盾时，以降低湿度为主。初采用较好的长寿无滴膜覆盖、拉紧棚膜外，降低棚内湿度的措施有：第一是加强通风排湿，晴天早晨揭开草栅后，在棚脊部开缝进行短时间通风排湿（20~25分钟），然后闭棚增温，当棚内温度较高时，再进行通风排湿，下午覆盖草栅前再通风20分钟。<span
				style="font-size: 12pt; font-family: Calibri;">连阴雨天通风排湿次数要达6~10次。早春放风最好采用顶部放风法。在小果型西瓜生长的中后期要求棚内有一级风。第二是控制浇水，灌水多，蒸发量大，极易造成棚内湿度过高，所以要尽量减少灌水次数，控制灌水量。</span>
		</p>
		<p style="line-height: 150%;"><span
				style="font-size: 12pt; font-family: Calibri;">（6）立架栽培&nbsp;：&nbsp;为适应大棚小果型西瓜密植的特点，多采用立架栽培，以充分利用棚内空间，更好地争取光能。常用竹竿或树棍、尼龙绳为架材。架型以单面立架为宜，此架型适于密植，通风、透光效果好，操作方便。架高1.7米左右，棚顶高2.2~2.5米，这样立架上端距棚顶要留下0.5米以上的空间（称空气活动层），利于空气流动，降低湿度，减少病害</span><span
				style="font-size: 12pt; font-family: 宋体;">。</span></p>
		<p style="line-height: 150%;">
			（7）整枝留瓜&nbsp;：&nbsp;大棚、日光温室小果型西瓜多采用单蔓整枝，也有少量双蔓整枝的，单蔓整枝有利于早熟。单蔓整枝时，选择第二雌花坐瓜，定瓜时每株只留1个发育好的瓜。主蔓长到25片真叶左右时打顶。搭架栽培中，保证坐果节位以上有15片或更多的健全叶片，对增加单瓜重、提高含糖量是有好处的。
		</p>
		<p style="line-height: 150%;"><span
				style="font-size: 12pt; font-family: Calibri;">（8）促进坐果技术&nbsp;：&nbsp;小果型西瓜开花座果期时，外界气温较低，棚内昆虫较少，必须采用相应措施解决授粉问题。天气正常情况下，人工授粉是最常用的方法，劳动力不足时，可利用蜜蜂进行昆虫传授。花期遇阴雨天，不易坐瓜，可使用座瓜灵等生长调节剂处理雌花促进座果，使用方法有两种：一种是喷洒法，在当天开花的雌花或开花前一天的雌花上，用座瓜灵可湿性粉剂200~400液喷洒瓜胎；另一种是涂抹法，用座瓜灵10~20倍液涂抹在瓜柄上。使用座瓜灵要注意使用浓度及方法，否则影响商品瓜质量。</span>
		</p>
		<p style="line-height: 150%;"><span style="font-size: 12pt; font-family: 宋体;">（</span><span
				style="font-size: 12pt; font-family: Calibri;">9）灌水&nbsp;：&nbsp;在整个生长期内土壤湿度不能低于48%，但不同</span><span
				style="color: rgb(0, 0, 0); font-size: 12pt; font-family: Calibri;">的</span><span
				style="font-size: 12pt; font-family: Calibri;">发育阶段，对水分的需要量也不同，苗期要少，伸蔓期开花期要够，果实膨大期要足，成熟期需要最少。小果型西瓜各生育为：定植到开花为最大持水量的70%，开花坐果期为80%，果实膨大期为80~85%，果实成熟期为55%。收获前7~10天停止浇水</span><span
				style="font-size: 12pt; font-family: 宋体;">。</span>通常大棚小果型西瓜浇一次伸蔓水和1~2次膨瓜水即可。注意浇膨瓜水时水量不可过大，以免引起病害。掌握浇到高畦2/3即可。
		</p>
		<p style="line-height: 150%;">
			（10）病虫害防治&nbsp;：&nbsp;大棚内温湿度较高，植株生长旺盛，茎叶郁密，病虫害容易滋生，因此应很好地控制灌水，注意通风换气，调节好棚内的温湿度，并及时防治病虫害的发生。</p>
		<h2 style="line-height: 150%;"><span
				style="color: rgb(207, 19, 34); font-size: 24px;"><strong>2、秋延后小果型西瓜栽培技术试验</strong></span></h2>
		<p style="text-indent: 24pt; line-height: 150%;">
			夏秋播种，秋冬收获的小果型西瓜生产属于反季节栽培，这一段时间的的气候特点与常规的春季栽培时的完全相反，即气温由高到低，前期主要是高温烈日，有时还有暴雨，后期温度偏低，这与小果型西瓜生长前期要求气温稍低、后期要求温度较高的条件正好相反，因此栽培设施要使保护地内前期降温、并能防雨、防虫，而后期能升温。因此，育苗时要有遮阳网或其他遮阳设施及防雨的棚膜等覆盖物，定植后如气温较高、日照很强，棚膜上也要增加遮阳网，覆盖在大棚顶部塑料薄膜上，到栽培中后期撤除。第二提倡网膜结合、全面遮盖，即用防虫网把大棚下部也围起，使大棚成为一个封闭的小环境，这样可有效地将害虫拒于大棚外，大大减少虫害，也相应减少了病害和打药的次数。覆盖遮阳网及防虫网应于定植前准备好。育苗用的营养钵、营养土、过筛细土等无特殊要求，保护地无论竹木、钢管、水泥结构的大棚或温室均可进行反季节栽培。
		</p>
		<p style="line-height: 150%;">（1）品种选择</p>
		<p style="line-height: 150%;">
			选择的品种要早熟，若品种选择不当，温度达不到种植品种的有效积温，轻者糖度降低，重者导致栽培失败；一般以选择全生育期不超过90天（果实发育期不超过40天）的品种为宜；目前种植已较为成功的品种如中甜一号（或丰甜一号）类型、伊丽莎白类型、西薄洛托等白皮类型，也有极少早熟网纹品种。第二选择优质、高产、耐贮运的品种，脆肉类型比软肉类型要耐贮运，软肉类型的一般风味较好，可根据销售需要选择不同品种。
		</p>
		<p style="line-height: 150%;">（2）定植</p>
		<p style="line-height: 150%;">
			因植株在大田生长的时间短，一次施足基肥就基本能满足生长发育的需要，所以定植前要施足基肥，施用基肥时，速效氮肥应尽量少用，以防植株徒长、增加病害，氮、磷、钾比例为1:1:1。然后作高畦(畦高20厘米)盖地膜，高畦宽1~1.2米，定植前一天午后，苗床内浇一遍透水。栽苗时先在定植畦上定好株距，破膜打孔，孔内浇透水，然后将幼苗栽到孔中（幼苗土块顶面与地面相平或略低一些），用土轻轻压实后再复浇一次水，然后用细土围根，封好定植穴。定植时小苗一叶一心即可（不要超过二叶一心）。大棚内为充分利用空间，多采用密植立架栽培，若单蔓整枝一畦种双行，行株距为1.5~1.8米×0.35~0.4米，每亩可种植约2500株。因同一品种秋季栽培的生长势不如春季旺，因此种植密度可比春季稍加大。
		</p>
		<p style="line-height: 150%;">（3）大棚温湿度的管理</p>
		<p style="line-height: 150%;">
			管理原则是前期降温、控温，后期增温保温，尽可能降低空气湿度。定植后缓苗前，棚内温度应控制在30℃左右，缓苗后白天温度应不高于35℃，夜间不超过于20℃，温度高易使植株徒长，坐果期间温度以22～26℃为宜，坐果后提高到30℃，此时外界温度降低，需要盖膜增温。根据小果型西瓜生长对温度的要求及天气情况，栽培前期尤其是苗期因温度较高，遮阳网一般于上午10时至下午3时盖，以防高温强光，注意遮阴不能过度，防止徒长。栽培中后期气温降低，放下四周棚膜，通过适当放风来调节棚温，尽量满足小果型西瓜生长要求。小果型西瓜不耐湿，要防止高温高湿现象，浇水后要加大通风量，尽快降低湿度，夏季午后气温超过37℃时，害虫活动较少，这时可揭开防虫网一段时间加快通风然后再盖上，这样不影响防虫效果。
		</p>
		<p style="line-height: 150%;">（4）水分管理</p>
		<p style="line-height: 150%;">
			做畦前要浇足底水，定植后早浇缓苗水，伸蔓坐瓜前土壤要保持一定的湿度，开花坐果期不宜灌水，以免徒长影响坐果，花后七天进入果实膨大期，此时需水量大，土壤见干既浇，但要防止大水漫灌，果实成熟采收前七天停止浇水，以利提高果实品质。
		</p>
		<p style="line-height: 150%;">（5）植株管理：</p>
		<p style="line-height: 150%;">
			夏秋气温高，加上大棚遮阳网覆盖栽培，肥水条件较好的田块极易引起植株枝叶过于繁茂而不结瓜，因此在控制肥水的同时要及时整枝绑蔓。整枝多采用单蔓整枝方式，选留第二雌花坐果，整枝原则是前紧后松，坐瓜前严格整枝、去杈、摘心，瓜坐稳后不再整枝，随植株自然生长，以增加叶面积促进果实膨大，整枝宜在晴天进行。植株下部发黄的老叶要及时摘除，以利通风透光。棚内传粉昆虫少，花期要进行人工辅助授粉，每天清晨花开后采摘雄花，剥除花瓣，然后轻轻地在雌花上涂抹一下。
		</p>
		<p style="line-height: 150%;">（6）&nbsp;病虫害防治</p>
		<p style="line-height: 150%;">
			由于高温高湿病虫危害较重。尤其是虫害的发生与病毒病的感染。控制病毒病的发生成为栽培与否的关键。第一控制毒源，种子消毒、清除大棚及周围的杂草对减少毒源有一定作用。第二控制发病条件，覆盖遮阳网起到遮强光和降温的作用，适当晚播也可避开高温期的影响。第三控制传毒途径消灭蚜虫，方法有使用防虫网、挂银灰条膜避蚜、发现中心危害株及时打药等。另外还有霜霉病、白粉病等，虫害温室白粉虱、蚜虫、斑潜蝇为害，病虫害以预防为主，而且要早发现早防治。
		</p>
		<p style="line-height: 150%;">（7）适时采收</p>
		<p>秋冬茬栽培的果实成熟时外界气温较低，果实成熟速度缓慢，成熟的瓜可以留在瓜秧上延迟采收，根据市场需要，推迟上市，增加效益。采收时用剪刀剪成十字型果柄，单个包装，装箱。因秋季小果型西瓜是高档果品，价值高，所以一定要包装好，减少损失，增加效益。如果贮存，温度应控制在5~10℃。
		</p>
		<h2 style="text-align: justify; line-height: 150%;"><span
				style="color: rgb(207, 19, 34); font-size: 24px;"><strong>3、小果型西瓜小拱棚栽培技术</strong></span></h2>
		<p style="line-height: 150%;"><span
				style="font-size: 12pt; font-family: 宋体;">&nbsp;&nbsp;&nbsp;&nbsp;</span>小拱棚小果型西瓜栽培有双膜覆盖栽培（拱棚膜、地膜）、三膜覆盖栽培（拱棚、拱棚内简易小棚、地膜）或三膜加草帘形式，与大棚相比小拱棚一次性投资少，每年还可以换地，避免连作障碍。由于多层覆盖，小拱棚的播期在华北地区可提早到2月中旬，南方地区可在1月下旬到2月上旬。
		</p>
		<p style="line-height: 150%;">&nbsp;&nbsp;&nbsp;（1）整地作畦定植扣棚&nbsp;&nbsp;&nbsp;</p>
		<p style="line-height: 150%;">
			定植田选择通透性能好、昼夜温差较大、地温回升快、易于发苗的沙质壤土。上年前作收获后经秋耕风化，次年春每亩撒施优质厩肥3000公斤，耕翻耙平，按1.5米行距划印、开沟，每亩条施过磷酸钙40公斤，用耙将肥料与田土混匀，做成宽80厘米，高20厘米的龟背型高畦，铺上地膜，拱棚内地面全覆盖有利于降低空气湿度。小拱棚外开好配套沟系，达到雨后沟内不积水。上述工作在移栽前7天内进行完毕，以提高地温，利于定植缓苗。栽苗时，用制钵器在地膜上按株距打孔，将幼苗栽入孔内。双蔓整枝株距0.4米，多蔓整枝0.5米。据观测，东西向高畦的中央稍偏南处，是高畦地温最高的地方，故幼苗应栽于此。随移栽随插架扣棚。
		</p>
		<p style="line-height: 150%;">&nbsp;&nbsp;（2）拱棚管理&nbsp;&nbsp;&nbsp;</p>
		<p style="line-height: 150%;">
			覆盖期间的管理，最主要的是适时通风换气，严格控制棚内温度。通风应根据天气情况灵活掌握。无风的晴天要早通风，通风量要大，关闭时间晚些。阴雨低温天气应晚点通风，通风量要小，早点关闭。寒流到来或刮大风的天气可不通风。在天气正常情况下，每天通风与闭塑料薄膜的时间，通常在上午9~10时开始，下午16~17时以前结束。当棚温超过32℃时，就应开始逐步通风，切忌开始骤然放大通风量，以防冷空气大量进入棚内伤害幼苗。当棚温降至20~22℃时就应关闭塑料棚保温，使夜间棚内仍有较高的温度。小果型西瓜各发育阶段需要掌握的温度参照大棚进行。
		</p>
		<p style="line-height: 150%;">
			小拱棚保湿能力较强，土壤水分过多易徒长，应严格控制浇水。定植时浇足定植水，开始伸蔓再浇一次水，果实膨大时浇第三次水，收获前7~10天停止浇水。当外界雨水较多时，应注意防止雨水渗入棚内，增加土壤湿度。</p>
		<p style="line-height: 150%;">
			目前小果型西瓜小拱棚覆盖栽培，大部分是在植株进入开花期或幼果期以后，就撤掉薄膜，实际是小棚半覆盖栽培，实践证明，更好的作法是在定植后的整个生育期内进行覆盖，即使到后期也不撤棚，而只是拉起两侧薄膜放风，棚顶始终保持盖膜，这可起到防雨、防病，促进果实生长发育的作用，这种栽培方式是值得推广的。
		</p>
		<p style="line-height: 150%;">&nbsp;&nbsp;&nbsp;（3）整枝</p>
		<p style="line-height: 150%;">
			&nbsp;&nbsp;&nbsp;小果型西瓜的小棚栽培可不用支架，平地爬蔓。整枝以双蔓整枝和多蔓整枝为多。①双蔓整枝：双蔓整枝是小棚小果型西瓜最常用的一种整枝方式。当幼苗在2~3片真叶时就在苗床内摘心，定植后即长出3~4条子蔓，从中选择两条长势好、部位适宜的子蔓，其余子蔓疏掉，每株留瓜1~2个。②多蔓整枝：幼苗长到5片叶时对主蔓摘心，选留适宜子蔓3~4条，每株留瓜3~4个。上述两种整枝方法，其整枝原则是一样的。即前紧后松的整枝原则。坐瓜以前，严格进行整枝、去杈、摘心以及压叶等工作，待幼瓜坐稳后，一般不再整枝、压叶（植株过旺时可以再进行1~2次摘心），让植株自然生长，以增加光合叶面积，使果实迅速膨大，进而达到高产之目的。
		</p>
		<p style="line-height: 150%;">（4）护瓜</p>
		<p>小拱棚栽培，果实在地面上生长发育，贴地面的部分着色浅，成熟度不够且影响商品外观，为此应进行翻瓜。翻瓜时要轻拿轻放，每次翻转三分之一面，隔5~6天翻一次，成熟前共翻三次。结合翻瓜进行垫瓜，用草即可，垫瓜可使空气流通，防止高湿引起的腐烂。小棚栽培的防病等田间管理大体跟大棚相同。
		</p>
		<p><span style="font-size: 12pt; font-family: 宋体;">&nbsp;</span></p></div>`
	}, {
		"id": "3",
		"html": `<div style="padding:10px;">
  <h2 style="text-align: center;">
    <font face="黑体">不同作物伴生育苗对西瓜根际土壤微生态环境的影响</font>
  </h2>
  <p>
    <font face="黑体"><span style="font-size: 12.4px;">作者：赵卫星</span></font>
    <font face="黑体"><span style="font-size: 12.4px;">，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">康利允，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">高宁宁，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">程志强，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">赵光华，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">常高正，</span></font>
    <font face="黑体"><span style="font-size: 12.4px;">梁慎</span></font>
    <font face="黑体"><span style="font-size: 12.4px;">，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">李海伦，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">王慧颖，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">徐小利，</span></font><span style="font-size: 12.4px;"> </span>
    <font face="黑体"><span style="font-size: 12.4px;">李晓慧</span></font>
  </p>

  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: 等线; font-size: 10.5pt;"><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;"><font face="黑体">发表于：《山</font></span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;"><font face="黑体">东农业科学</font></span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;"><font face="黑体">》</font></span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;">&nbsp;2022</span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;"><font face="黑体">,</font></span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;">54</span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;"><font face="黑体">（</font><font face="黑体">5）：1</font></span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;">28~133</span></b></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">&nbsp; 为探明种间伴生改善西瓜根际微土壤生态环境的作用机理，以茼蒿</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">大葱</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">小麦与目标作物西瓜同穴育苗，研究伴生对西瓜根际土壤</font></span><span style="font-family:宋体;font-size:10.0000pt;">pH</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">值</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">EC</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">值及微生物</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">酶活性的影响</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">。</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">结果表明，与单作相比，不同伴生育苗模式均可改变西瓜根际土壤的酸碱性和电导率，促进根际土壤细菌和放线菌的生长，降低真菌数量，改善根际微生物多样性，提高根际土壤脱氢酶</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">脲酶</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">转化酶及多酚氧化酶的活性</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">。</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">综合考虑，茼蒿的改良作用明显优于小麦和大葱，其与中晚熟</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">早熟西瓜伴生后，</font></span><span style="font-family:宋体;font-size:10.0000pt;">pH</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">值分别提高</font></span><span style="font-family:宋体;font-size:10.0000pt;">69.05%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">25. 93%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">，</font></span><span style="font-family:宋体;font-size:10.0000pt;">EC </span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">值降低</font></span><span style="font-family:宋体;font-size:10.0000pt;">47. 62%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">47. 37%</span><span style="font-family:宋体;font-size:10.0000pt;">;</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">生物多样性指数提高</font></span><span style="font-family:宋体;font-size:10.0000pt;">37. 77%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">11. 98%</span><span style="font-family:宋体;font-size:10.0000pt;">; </span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">土壤脱氢酶活性提高</font></span><span style="font-family:宋体;font-size:10.0000pt;">105. 79%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">160. 78%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">，转化酶活性提高</font></span><span style="font-family:宋体;font-size:10.0000pt;">24. 56%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">14. 93%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">，脲酶活性提高</font></span><span style="font-family:宋体;font-size:10.0000pt;">15. 89%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">86. 66%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">，多酚氧化酶提高</font></span><span style="font-family:宋体;font-size:10.0000pt;">18. 18%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;">22. 83%</span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">。</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">相关性分析结果显示，土壤微生物数量与土壤脱氢酶</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">转化酶和多酚氧化酶活性及其他相关微生物数量之间存在显著相关性</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">。</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">综上所述，茼蒿</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">大葱</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">小麦与不同基因型西瓜伴生均提高根区土壤酶活性，改善微生物结构，以茼蒿伴生育苗效果最好</font></span><span style="font-family:宋体;font-size:10.0000pt;">; </span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">同时，可以通过人为改变土壤相关酶活性调节根际土壤微生物数量和种类以降低西瓜土传病害的发生</font></span><span style="font-family:宋体;font-size:10.0000pt;"><font face="宋体">。</font></span></p>



  <p>
    <font face="宋体"><b style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14.4px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/wzt1.png?sign=b7327e93f364a9613d657ac0a7ccbe84&t=1656161312" style="margin: 0px auto;width: 90vw; display: block;" /></b></font>
  </p>



  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/wzt2.png?sign=fb7fa44726d13b4ad3d59c87edb12a42&t=1656161274"
    style="width: 90vw; margin: 0px auto; display: block;" /></div>
<div style="padding:10px;">

  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">&nbsp; 土壤微生物是土壤生态系统的重要组成部分，植物的相互作用是通过相关微生物直接或间接的影响来实现</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">。</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">本研究发现不同基因型西瓜与小麦</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">、</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">大葱和茼蒿伴生育苗均可促进根际土壤细菌和放线菌的生长，降低真菌数量，改善根际微生物多样性</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">。</font></span></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">&nbsp; 本研究也发现，与西瓜单作相比，不同基因型西瓜与小麦、大葱和茼蒿伴生育苗均可提高根际土壤脱氢酶、转化酶、脲酶及多酚氧化酶活性，充分说明这</font></span><span style="font-family:宋体;font-size:10.5000pt;">3种作物与西瓜伴生有助于激化</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">土壤酶活性。这可能是由于伴生加快了西瓜根系有机物的转化，增加了根系和微生物向土壤中释放酶的数量。从</font></span><span style="font-family:宋体;font-size:10.5000pt;">3种作物伴生对西瓜根际酶活性</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">影响的差异上来看，茼蒿的作用效果要优于小麦和大葱，可能是茼蒿根系分泌物更能促进西瓜对土壤中营养物质的吸收和利用，从而提高土壤酶的活性。</font></span></p>
  <p style="margin: 0pt 0pt 0.0001pt; text-align: justify; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体"></font><br /></span></p>

  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">木霉</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">菌</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">防</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">治</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">西</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">瓜</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">枯萎</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">病</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">效</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">果</font></span><span style="font-family:黑体;font-size:18.0000pt;"><font face="黑体">试验</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">作者：郭珠</font></span><span style="font-family:黑体;font-size:12.0000pt;">&nbsp;</span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">张</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">瑞雪</font></span><span style="font-family:黑体;font-size:12.0000pt;">&nbsp;</span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">张</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">会</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">龙</font></span><span style="font-family:黑体;font-size:12.0000pt;">&nbsp;</span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">段</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">培</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">姿</font></span><span style="font-family:黑体;font-size:12.0000pt;">&nbsp;</span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">张</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">淑</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">娜</font></span><span style="font-family:黑体;font-size:12.0000pt;">&nbsp;</span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">刘</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">秀</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">丽</font></span><span style="font-family:黑体;font-size:12.0000pt;">&nbsp;</span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">姬</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">玉</font></span><span style="font-family:黑体;font-size:12.0000pt;"><font face="黑体">霞</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;"><font face="黑体">发表于：《现代农业科技》</font><font face="黑体">2</font></span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;">022</span></b><b><span style="font-family:黑体;font-weight:bold;font-size:14.0000pt;"><font face="黑体">年第</font><font face="黑体">5期</font></span></b></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">&nbsp; 选取木霉制剂哈茨木霉、绿色木霉，</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">结合</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">传统的防治药剂</font></span><span style="font-family:宋体;font-size:10.5000pt;">15%恶霉灵、6%春雷霉素对西瓜枯萎</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">病进行防治。结果表明：</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">木霉菌防治西瓜枯萎病效果</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">明显，</font></span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">哈茨木霉防治效果优于绿色木霉。</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">&nbsp; 西瓜枯萎病俗称</font><font face="宋体">“死秧病”，属于真菌界半知菌类，是由尖孢镰刀菌西瓜专化型侵染引起的一种典型的系统侵染型土传病害，是西瓜种植过程中严重的病害之一。西瓜枯萎病在我国各西瓜产区均有发生，并造成较大损失。该病属土传性病害，病菌在土壤中存活时间长，防治难度大，尤其在西瓜种植重茬地块，发病率在</font></span><span style="font-family:宋体;font-size:10.5000pt;">30%以上，严重的地块达到80%以上，甚至会</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">造成绝产绝收，截至目前，国内外还未有根治方法。由于在对作物枯萎病害的防治过程中长期大量使用化学农药，从而增强了其病原菌的抗性，造成防治效果差的问题。近年来，木霉菌作为生物防治领域中潜力较强的生防菌，在植物病害生物防治中发挥作用重大。为此，衡水市农业农村局联合阜城县农业农村局在国家农产品地理标志</font><font face="宋体">“漫河西瓜”主产区的衡水市阜城县，选取木霉菌中的哈茨木霉、绿色木霉，安排了西瓜枯萎病的田间防治试验，并针对西瓜枯萎病总结出一套有效的绿色防治措施。</font></span></p>





  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/wzt3.png?sign=c0deacbf6a98cbad4726c64dd2bda45a&t=1656161225" style="width: 90vw; margin: 0px auto; display: block;" />

  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">&nbsp; 由表</font></span><span style="font-family:宋体;font-size:10.5000pt;">1 可知，以木霉制剂哈茨木霉、绿色木霉分</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">别处理的西瓜植株发病率为</font></span><span style="font-family:宋体;font-size:10.5000pt;">21.67%和30.0%，明显低</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">于药剂对照</font></span><span style="font-family:宋体;font-size:10.5000pt;">(6%春雷霉素发病率38.0%、15%恶霉灵发</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">病率为</font></span><span style="font-family:宋体;font-size:10.5000pt;">42.9%)和空白对照，由此说明木霉菌对西瓜枯</span><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">萎病的防治效果明显。。而且调查发现，该制剂处理的小区内种植的西瓜植株长势旺盛，叶片大而浓绿。试验证明，木霉菌能明显促进西瓜对氮磷</font></span></p>
  <p style="text-align: left; margin: 0pt 0pt 0.0001pt; font-family: 等线; font-size: 10.5pt;"><span style="font-family:宋体;font-size:10.5000pt;"><font face="宋体">钾等养分的吸收，对作物具有一定的促生长作用。</font></span></p>



  <p><br /></p>



  <br /></div>`
	}, {
		"id": "5",
		"html": `<div style="padding:10px">
 
  <p style="text-indent: 21pt; text-align: left; margin: 0pt 0pt 0.0001pt; font-family: Calibri; font-size: 10.5pt;"><span style="font-family:Calibri;font-size:10.5000pt;"><font face="宋体"><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/zjwz.jpg?sign=8a39449d9b274e75f530c1cd510058f2&t=1656919024" style="width: 90vw; margin: 0px auto; display: block;" /></font><br /></span></p>





</div>`
	}, {
		"id": "2",
		"html": `<div style="padding:10px; ">
  
  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/pzxx1.jpg?sign=5e91f4f8bbe335cb1e2bd35ac3968682&t=1656946688" style="width: 100%; margin: 0px auto; display: block; padding: 0;"  />
  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/pzxx2.jpg?sign=8cf530782019bd13c252efb228573dce&t=1656946801" style="width: 100%; margin: 0px auto; display: block; padding: 0;" />
  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/pzxx3.jpg?sign=d69130d131142a9404041ab12251a9e6&t=1656946842" style="width: 100%; margin: 0px auto; display: block; padding: 0;" />
  <img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/pzxx4.jpg?sign=4db6b0dcabeb596870e84cf0d15931b1&t=1656946857" style="width: 100%; margin: 0px auto; display: block; padding: 0;" />
  
</div>`
		
	}, {
		"id": "4",
		"html": `<div style="padding:10px; "><img src="https://7761-watermelon-0gbmos3r08d8c04b-1311486156.tcb.qcloud.la/WaterMelon/image/img/zhlc.jpg?sign=10dd9aa4f50c921c5e253407bf5d2b84&t=1656917581" style="margin: 0px auto; display: block; width: 100%; " />

</div>`
	}]
}
